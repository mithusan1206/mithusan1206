import { db } from './db.js';
import { eachDate, isoDate, parseIso } from './dates.js';
import { reapplyExchanges } from './exchanges.js';
import { isHoliday, isWeekend } from './holidays.js';

const LEAVE_CODE = { CA: 'CA', RTT: 'RTT', Absence: 'ABS' };

function dayOfYear(date) {
  const start = new Date(date.getFullYear(), 0, 0);
  return Math.floor((date - start) / 86400000);
}

export function generateRange(from, to, maxDays = 62) {
  const dates = eachDate(from, to);
  if (dates.length === 0 || dates.length > maxDays) {
    const error = new Error(`La période doit contenir entre 1 et ${maxDays} jours`);
    error.status = 400;
    throw error;
  }

  const techs = db.prepare(
    `SELECT id, quota FROM users WHERE role = 'technicien' AND active = 1 ORDER BY name`,
  ).all();
  const posts = db.prepare(
    `SELECT code, required_agents FROM posts WHERE active = 1 ORDER BY name`,
  ).all();
  const allowed = new Set(
    db.prepare(
      `SELECT h.user_id, p.code AS post_code
       FROM habilitations h
       JOIN posts p ON p.id = h.post_id
       WHERE h.status IN ('Habilité', 'Expire bientôt') AND p.active = 1`,
    ).all().map((row) => `${row.user_id}|${row.post_code}`),
  );
  const approved = db.prepare(
    `SELECT user_id, type, start_date, end_date FROM requests
     WHERE status = 'Validée' AND type IN ('CA', 'RTT', 'Absence')`,
  ).all();

  const workingDays = dates.filter((date) => {
    const day = parseIso(date);
    return !isHoliday(day) && !isWeekend(day);
  }).length;
  const cap = new Map(techs.map((tech) => [tech.id, Math.round(workingDays * Number(tech.quota ?? 100) / 100)]));
  const used = new Map(techs.map((tech) => [tech.id, 0]));
  const remove = db.prepare(
    `DELETE FROM assignments
     WHERE date >= ? AND date <= ?
       AND user_id IN (SELECT id FROM users WHERE role = 'technicien' AND active = 1)`,
  );
  const insert = db.prepare(
    `INSERT INTO assignments (user_id, date, code) VALUES (?, ?, ?)`,
  );

  db.exec('BEGIN');
  try {
    remove.run(from, to);
    for (const date of dates) {
      const day = parseIso(date);
      const holiday = isHoliday(day);
      const weekend = isWeekend(day);
      const taken = new Set();

      for (const tech of techs) {
        if (holiday) {
          insert.run(tech.id, date, 'J.F.');
          taken.add(tech.id);
          continue;
        }
        const leave = approved.find((row) =>
          row.user_id === tech.id && row.start_date <= date && row.end_date >= date,
        );
        if (leave) {
          insert.run(tech.id, date, LEAVE_CODE[leave.type]);
          taken.add(tech.id);
          continue;
        }
        if (weekend) {
          insert.run(tech.id, date, 'R.H.');
          taken.add(tech.id);
        }
      }

      if (holiday || weekend) continue;

      const free = techs.filter((tech) => !taken.has(tech.id));
      const offset = free.length ? dayOfYear(day) % free.length : 0;
      const rotated = free.slice(offset).concat(free.slice(0, offset));

      for (const post of posts) {
        let need = post.required_agents;
        for (const tech of rotated) {
          if (need === 0) break;
          if (taken.has(tech.id)) continue;
          if (!allowed.has(`${tech.id}|${post.code}`)) continue;
          if ((used.get(tech.id) ?? 0) >= (cap.get(tech.id) ?? 0)) continue;
          insert.run(tech.id, date, post.code);
          taken.add(tech.id);
          used.set(tech.id, (used.get(tech.id) ?? 0) + 1);
          need -= 1;
        }
      }

      for (const tech of techs) {
        if (!taken.has(tech.id)) insert.run(tech.id, date, 'R.H.');
      }
    }
    reapplyExchanges(from, to);
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

export function regenerateDemoWindow() {
  const users = db.prepare(`SELECT COUNT(*) AS count FROM users`).get();
  if (users.count === 0) return;
  const start = new Date();
  const from = isoDate(new Date(start.getFullYear(), start.getMonth(), 1));
  const to = isoDate(new Date(start.getFullYear(), start.getMonth() + 3, 0));
  generateRange(from, to, 100);
}

export function applyLeave(userId, type, start, end) {
  const code = LEAVE_CODE[type];
  if (!code) return;
  const update = db.prepare(
    `UPDATE assignments SET code = ? WHERE user_id = ? AND date = ?`,
  );
  const insert = db.prepare(
    `INSERT INTO assignments (user_id, date, code) VALUES (?, ?, ?)`,
  );
  for (const date of eachDate(start, end)) {
    const result = update.run(code, userId, date);
    if (result.changes === 0) insert.run(userId, date, code);
  }
}
