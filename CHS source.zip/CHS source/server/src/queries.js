import { db } from './db.js';
import {
  agoLabel,
  dayLabel,
  eachDate,
  formatRange,
  frTime,
  isoDate,
  longLabel,
  monthLabel,
  parseIso,
  shortDay,
} from './dates.js';
import { nextServiceDate } from './holidays.js';
import { exchangeView, settleExchange } from './exchanges.js';
import { applyLeave } from './planning.js';

const OFF = new Set(['R.H.', 'CA', 'RTT', 'J.F.', 'ABS']);
const WORKING_OK = new Set(['Habilité', 'Expire bientôt']);

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    role: user.role,
    jobTitle: user.job_title,
    contract: user.contract,
    labName: user.lab_name,
  };
}

function technicians() {
  return db.prepare(
    `SELECT id, name, job_title, contract, quota FROM users WHERE role = 'technicien' AND active = 1 ORDER BY name`,
  ).all();
}

function activePosts() {
  return db.prepare(
    `SELECT id, name, code, description, start_time, end_time, color, required_agents
     FROM posts WHERE active = 1 ORDER BY name`,
  ).all();
}

function assignmentMap(date) {
  const rows = db.prepare(`SELECT user_id, code FROM assignments WHERE date = ?`).all(date);
  return new Map(rows.map((row) => [row.user_id, row.code]));
}

function habilitationMap() {
  const rows = db.prepare(
    `SELECT h.user_id, p.code AS post_code, h.status, h.valid_until
     FROM habilitations h JOIN posts p ON p.id = h.post_id`,
  ).all();
  const map = new Map();
  for (const row of rows) {
    const list = map.get(row.user_id) ?? [];
    list.push(row);
    map.set(row.user_id, list);
  }
  return map;
}

function isQualified(habs, code) {
  return habs.some((row) => row.post_code === code && WORKING_OK.has(row.status));
}

function expiringSoon(habs) {
  return habs.some((row) => row.status === 'Expire bientôt' || row.status === 'Expirée');
}

function validCount(habs) {
  return habs.filter((row) => WORKING_OK.has(row.status)).length;
}

function presence(code) {
  if (!code || code === 'R.H.' || code === 'J.F.') return 'off';
  if (code === 'ABS') return 'absent';
  if (code === 'CA' || code === 'RTT') return 'leave';
  return 'present';
}

function presenceLabel(kind, code) {
  if (kind === 'present') return 'Présent';
  if (kind === 'absent') return 'Absent';
  if (kind === 'leave') return code === 'RTT' ? 'RTT' : 'Congé';
  return 'Repos';
}

function coverageFor(date) {
  const counts = new Map();
  for (const row of db.prepare(`SELECT code FROM assignments WHERE date = ?`).all(date)) {
    counts.set(row.code, (counts.get(row.code) ?? 0) + 1);
  }
  return activePosts().map((post) => {
    const filled = counts.get(post.code) ?? 0;
    const coverage = post.required_agents === 0
      ? 0
      : Math.min(100, Math.round((filled / post.required_agents) * 100));
    return { name: post.code, coverage, filled, required: post.required_agents };
  });
}

function timeFor(code) {
  const post = db.prepare(`SELECT start_time, end_time FROM posts WHERE code = ?`).get(code);
  if (!post) return '';
  return `${frTime(post.start_time)}–${frTime(post.end_time)}`;
}

export function mePayload(user) {
  return publicUser(user);
}

export function dashboardFor(user) {
  const now = new Date();
  const today = isoDate(now);
  const service = nextServiceDate(now);
  const serviceIso = isoDate(service);
  const isServiceDay = serviceIso === today;
  const techs = technicians();
  const todayMap = assignmentMap(today);
  const serviceMap = assignmentMap(serviceIso);
  const habs = habilitationMap();
  const cadre = user.role === 'cadre';

  let present = 0;
  let absent = 0;
  for (const tech of techs) {
    const kind = presence(todayMap.get(tech.id));
    if (kind === 'present') present += 1;
    if (kind === 'absent' || kind === 'leave') absent += 1;
  }

  const coverage = coverageFor(serviceIso);
  const covered = coverage.filter((post) => post.filled >= post.required).length;
  const pendingRows = db.prepare(
    `SELECT COUNT(*) AS count FROM requests
     WHERE status = 'En attente' OR (type = 'Échange' AND status = 'En attente du collègue')`,
  ).get();

  const alerts = [];
  for (const post of coverage) {
    if (post.filled >= post.required) continue;
    const missing = post.required - post.filled;
    alerts.push({
      id: `post-${post.name}`,
      level: 'Urgent',
      message: `Le poste ${post.name} nécessite encore ${missing} agent habilité le ${shortDay(serviceIso)}.`,
      timeLabel: isServiceDay ? "Aujourd'hui" : longLabel(service),
    });
  }
  for (const tech of techs) {
    for (const hab of habs.get(tech.id) ?? []) {
      if (hab.status !== 'Expire bientôt' || !hab.valid_until) continue;
      alerts.push({
        id: `hab-${tech.id}-${hab.post_code}`,
        level: 'Attention',
        message: `L'habilitation ${hab.post_code} de ${tech.name} expire le ${shortDay(hab.valid_until)}.`,
        timeLabel: 'Habilitation',
      });
    }
  }

  const requestSql = cadre
    ? `SELECT r.id, u.name, r.type, r.start_date, r.end_date, r.reason, r.status,
              COALESCE(p.first_name, p.name, '') AS partner_name
       FROM requests r JOIN users u ON u.id = r.user_id
       LEFT JOIN users p ON p.id = r.partner_id
       WHERE r.status = 'En attente' OR (r.type = 'Échange' AND r.status = 'En attente du collègue')
       ORDER BY r.created_at DESC LIMIT 5`
    : `SELECT r.id, u.name, r.type, r.start_date, r.end_date, r.reason, r.status
       FROM requests r JOIN users u ON u.id = r.user_id
       WHERE r.user_id = ? ORDER BY r.created_at DESC LIMIT 5`;
  const requestRows = cadre
    ? db.prepare(requestSql).all()
    : db.prepare(requestSql).all(user.id);

  const planning = techs.map((tech) => {
    const code = (isServiceDay ? serviceMap : todayMap).get(tech.id) ?? 'R.H.';
    const ownHabs = habs.get(tech.id) ?? [];
    return {
      userId: tech.id,
      name: tech.name,
      post: code,
      time: OFF.has(code) ? presenceLabel(presence(code), code) : timeFor(code),
      habilite: OFF.has(code) ? true : isQualified(ownHabs, code),
    };
  });

  const firstName = user.name.startsWith('Dr.') ? user.name : user.name.split(' ')[0];

  return {
    viewerName: user.name,
    greeting: `Bonjour, ${firstName}`,
    todayLabel: longLabel(now),
    subtitle: isServiceDay
      ? "Voici la situation du laboratoire aujourd'hui"
      : `Jour de repos. La couverture affichée est celle du ${longLabel(service).toLowerCase()}.`,
    coverageTitle: isServiceDay ? 'Couverture des postes' : `Couverture — ${longLabel(service)}`,
    canValidate: cadre,
    kpis: [
      {
        label: 'Personnel présent',
        value: `${present}/${techs.length}`,
        sub: isServiceDay ? `${absent} absents` : 'Jour de repos',
        tone: 'sage',
      },
      {
        label: 'Postes couverts',
        value: coverage.length ? `${covered}/${coverage.length}` : '—',
        sub: coverage.length === 0
          ? 'Aucun poste'
          : isServiceDay
            ? (covered === coverage.length ? 'Complet' : 'Incomplet')
            : shortDay(serviceIso),
        tone: 'neon',
      },
      {
        label: 'Demandes',
        value: String(pendingRows.count),
        sub: 'En attente',
        tone: 'pink',
      },
      {
        label: 'Alertes',
        value: String(alerts.length),
        sub: alerts.some((alert) => alert.level === 'Urgent') ? 'Urgent' : 'À suivre',
        tone: 'orange',
      },
    ],
    planning,
    coverage: coverage.map(({ name, coverage: value }) => ({ name, coverage: value })),
    pendingBadge: pendingRows.count,
    requests: requestRows.map((row) => ({
      id: row.id,
      name: row.name,
      type: row.type,
      dates: formatRange(row.start_date, row.end_date),
      reason: row.reason,
      status: row.status,
      waitingFor: row.status === 'En attente du collègue' ? (row.partner_name || '') : '',
    })),
    alerts: alerts.slice(0, 6),
  };
}

export function planningFor(user, from, to) {
  const techs = technicians();
  const cells = db.prepare(
    `SELECT user_id, date, code FROM assignments WHERE date >= ? AND date <= ?`,
  ).all(from, to);
  const hours = {};
  for (const post of activePosts()) {
    hours[post.code] = { start: frTime(post.start_time), end: frTime(post.end_time) };
  }
  for (const code of ['R.H.', 'CA', 'RTT', 'J.F.', 'ABS']) {
    hours[code] = { start: '', end: '' };
  }
  return {
    canGenerate: user.role === 'cadre',
    posts: activePosts().map((post) => ({
      id: post.id,
      name: post.name,
      code: post.code,
      description: post.description,
      color: post.color,
      startTime: post.start_time,
      endTime: post.end_time,
      active: true,
      habilitatedCount: 0,
    })),
    agents: techs.map((tech) => ({
      id: tech.id,
      name: tech.name,
      role: `${tech.job_title} · ${tech.quota ?? 100}%`,
    })),
    cells: cells.map((cell) => ({
      userId: cell.user_id,
      date: cell.date,
      code: cell.code,
    })),
    hours,
  };
}

export function teamFor(query, filter) {
  const today = isoDate(new Date());
  const map = assignmentMap(today);
  const habs = habilitationMap();
  const needle = query.trim().toLowerCase();

  const members = technicians().map((tech) => {
    const code = map.get(tech.id) ?? 'R.H.';
    const kind = presence(code);
    const own = habs.get(tech.id) ?? [];
    return {
      id: tech.id,
      name: tech.name,
      role: `${tech.job_title} · ${tech.contract}`,
      post: kind === 'present' ? code : '—',
      status: kind,
      statusLabel: presenceLabel(kind, code),
      habilitations: validCount(own),
      expiring: expiringSoon(own),
    };
  });

  const counts = {
    total: members.length,
    present: members.filter((member) => member.status === 'present').length,
    absent: members.filter((member) => member.status === 'absent' || member.status === 'leave').length,
    off: members.filter((member) => member.status === 'off').length,
  };

  const filtered = members.filter((member) => {
    if (needle && !member.name.toLowerCase().includes(needle)) return false;
    if (filter === 'Présents') return member.status === 'present';
    if (filter === 'Absents') return member.status === 'absent' || member.status === 'leave';
    if (filter === 'Habilités') return member.habilitations > 0;
    if (filter === 'Habilitations expirantes') return member.expiring;
    return true;
  });

  return { counts, members: filtered };
}

function requestItem(row, viewer) {
  const cadre = viewer.role === 'cadre';
  const exchange = exchangeView(row);
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    dates: formatRange(row.start_date, row.end_date),
    reason: row.reason,
    status: row.status,
    createdLabel: agoLabel(row.created_at),
    canValidate: cadre && row.status === 'En attente' && row.type !== 'Échange',
    canApproveExchange: cadre && row.type === 'Échange' && row.status === 'En attente' && row.partner_status === 'acceptée',
    canAnswerExchange: viewer.role === 'technicien' && row.partner_id === viewer.id && row.status === 'En attente du collègue',
    canManageExchange: row.type === 'Échange' && row.user_id === viewer.id && (row.status === 'En attente du collègue' || row.status === 'En attente'),
    exchange,
  };
}

export function requestsFor(user, category) {
  const cadre = user.role === 'cadre';
  const clauses = [];
  const params = [];
  if (!cadre) {
    clauses.push('(r.user_id = ? OR r.partner_id = ?)');
    params.push(user.id, user.id);
  }
  if (category && category !== 'Tout') {
    clauses.push('r.type = ?');
    params.push(category);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const rows = db.prepare(
    `SELECT r.*, u.name
     FROM requests r JOIN users u ON u.id = r.user_id
     ${where}
     ORDER BY CASE WHEN r.status IN ('En attente', 'En attente du collègue') THEN 0 ELSE 1 END, r.created_at DESC`,
  ).all(...params);
  const pending = cadre
    ? db.prepare(
      `SELECT COUNT(*) AS count FROM requests
       WHERE status = 'En attente' OR (type = 'Échange' AND status = 'En attente du collègue')`,
    ).get()
    : db.prepare(
      `SELECT COUNT(*) AS count FROM requests
       WHERE status IN ('En attente', 'En attente du collègue') AND (user_id = ? OR partner_id = ?)`,
    ).get(user.id, user.id);
  return {
    pending: pending.count,
    canRequest: !cadre,
    items: rows.map((row) => requestItem(row, user)),
  };
}

export function decideRequest(actor, requestId, action) {
  if (actor.role !== 'cadre') {
    const error = new Error('Réservé au cadre de santé');
    error.status = 403;
    throw error;
  }
  const row = db.prepare(`SELECT * FROM requests WHERE id = ?`).get(requestId);
  if (!row) {
    const error = new Error('Demande introuvable');
    error.status = 404;
    throw error;
  }
  if (row.type === 'Échange' && row.partner_id) {
    settleExchange(actor, row, action);
    const updatedExchange = db.prepare(
      `SELECT r.*, u.name FROM requests r JOIN users u ON u.id = r.user_id WHERE r.id = ?`,
    ).get(row.id);
    return requestItem(updatedExchange, actor);
  }
  if (row.status !== 'En attente') {
    const error = new Error('Cette demande est déjà traitée');
    error.status = 409;
    throw error;
  }

  const status = action === 'approve' ? 'Validée' : 'Refusée';
  const days = eachDate(row.start_date, row.end_date).length;
  const balance = db.prepare(`SELECT * FROM leave_balances WHERE user_id = ?`).get(row.user_id);

  if (action === 'approve' && row.type === 'CA' && balance.ca_remaining < days) {
    const error = new Error('Solde de CA insuffisant');
    error.status = 409;
    throw error;
  }
  if (action === 'approve' && row.type === 'RTT' && balance.rtt_remaining < days) {
    const error = new Error('Solde de RTT insuffisant');
    error.status = 409;
    throw error;
  }

  const agent = db.prepare(`SELECT name FROM users WHERE id = ?`).get(row.user_id);
  const now = new Date().toISOString();
  const verb = action === 'approve' ? 'validé' : 'refusé';

  db.exec('BEGIN');
  try {
    db.prepare(
      `UPDATE requests SET status = ?, resolved_at = ?, resolved_by = ? WHERE id = ?`,
    ).run(status, now, actor.id, row.id);
    if (action === 'approve' && row.type === 'CA') {
      db.prepare(`UPDATE leave_balances SET ca_remaining = ca_remaining - ? WHERE user_id = ?`).run(days, row.user_id);
      applyLeave(row.user_id, row.type, row.start_date, row.end_date);
    } else if (action === 'approve' && row.type === 'RTT') {
      db.prepare(`UPDATE leave_balances SET rtt_remaining = rtt_remaining - ? WHERE user_id = ?`).run(days, row.user_id);
      applyLeave(row.user_id, row.type, row.start_date, row.end_date);
    } else if (action === 'approve' && row.type === 'Absence') {
      applyLeave(row.user_id, row.type, row.start_date, row.end_date);
    }
    db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
      actor.id, `${row.type} ${verb} — ${agent.name}`, now,
    );
    db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
      row.user_id, `${row.type} ${verb} — ${formatRange(row.start_date, row.end_date)}`, now,
    );
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }

  const updated = db.prepare(
    `SELECT r.*, u.name FROM requests r JOIN users u ON u.id = r.user_id WHERE r.id = ?`,
  ).get(row.id);
  return requestItem(updated, actor);
}

function profileBody(target, viewer) {
  const today = new Date();
  const todayKey = isoDate(today);
  const code = db.prepare(`SELECT code FROM assignments WHERE user_id = ? AND date = ?`).get(target.id, todayKey)?.code ?? 'R.H.';
  const kind = presence(code);
  const leave = db.prepare(`SELECT * FROM leave_balances WHERE user_id = ?`).get(target.id);
  const habs = db.prepare(
    `SELECT p.id AS post_id, p.code, p.name, h.status, h.valid_until
     FROM habilitations h JOIN posts p ON p.id = h.post_id
     WHERE h.user_id = ? ORDER BY p.name`,
  ).all(target.id);
  const canAssign = viewer.role === 'cadre' && target.role === 'technicien';
  const catalog = canAssign
    ? db.prepare(`SELECT id, code, name, color, active FROM posts ORDER BY active DESC, name`).all().map((post) => {
      const hab = habs.find((row) => row.post_id === post.id);
      const enabled = !!hab && (hab.status === 'Habilité' || hab.status === 'Expire bientôt');
      return {
        id: post.id,
        code: post.code,
        name: post.name,
        color: post.color,
        active: post.active === 1,
        enabled,
        status: hab?.status ?? 'Non habilité',
      };
    })
    : [];
  const activity = db.prepare(
    `SELECT action, created_at FROM activity WHERE user_id = ? ORDER BY id DESC LIMIT 5`,
  ).all(target.id);

  const first = new Date(today.getFullYear(), today.getMonth(), 1);
  const days = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const start = isoDate(first);
  const end = isoDate(new Date(today.getFullYear(), today.getMonth(), days));
  const marked = db.prepare(
    `SELECT date FROM assignments
     WHERE user_id = ? AND date >= ? AND date <= ? AND code IN ('CA', 'RTT', 'ABS')`,
  ).all(target.id, start, end).map((row) => parseIso(row.date).getDate());

  return {
    viewingSelf: viewer.id === target.id,
    canAssign,
    name: target.name,
    jobTitle: target.job_title,
    labName: target.lab_name,
    statusLabel: kind === 'present' ? `Présent · Poste ${code}` : presenceLabel(kind, code),
    leave: {
      caRemaining: leave?.ca_remaining ?? 0,
      caTotal: leave?.ca_total ?? 0,
      rttRemaining: leave?.rtt_remaining ?? 0,
      rttTotal: leave?.rtt_total ?? 0,
    },
    habilitations: habs.map((hab) => ({
      post: hab.code,
      status: hab.status,
      validLabel: hab.valid_until
        ? (hab.status === 'Expire bientôt' ? `Expire le ${shortDay(hab.valid_until)}` : `Valide jusqu'au ${shortDay(hab.valid_until)}`)
        : '',
    })),
    catalog,
    calendar: {
      monthLabel: monthLabel(today),
      offset: (first.getDay() + 6) % 7,
      days,
      marked,
      today: today.getDate(),
    },
    activity: activity.map((item) => ({
      action: item.action,
      dateLabel: dayLabel(item.created_at),
    })),
  };
}

export function profileFor(viewer, userId) {
  const target = db.prepare(`SELECT * FROM users WHERE id = ?`).get(userId);
  if (!target) {
    const error = new Error('Profil introuvable');
    error.status = 404;
    throw error;
  }
  if (viewer.role !== 'cadre' && viewer.id !== target.id) {
    const error = new Error('Profil non autorisé');
    error.status = 403;
    throw error;
  }
  return profileBody(target, viewer);
}

export function recordPlanningActivity(user, from, to) {
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
    user.id,
    `Planning généré — ${formatRange(from, to)}`,
    new Date().toISOString(),
  );
}
