import { randomBytes, scryptSync } from 'node:crypto';
import { db } from './db.js';
import { isoDate } from './dates.js';

const DATE = /^\d{4}-\d{2}-\d{2}$/;
const LOGIN = /^[a-z0-9][a-z0-9._@-]{2,63}$/;
const OFF = ['R.H.', 'CA', 'RTT', 'J.F.', 'ABS'];

function fail(message, status) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function requireCadre(user) {
  if (user.role !== 'cadre') fail('Réservé au cadre de santé', 403);
}

function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 32).toString('hex');
  return `${salt}:${hash}`;
}

function readType(id) {
  const type = db.prepare(`SELECT * FROM personnel_types WHERE id = ?`).get(id);
  if (!type) fail('Catégorie introuvable', 404);
  return type;
}

function readPerson(id) {
  const row = db.prepare(
    `SELECT u.*, t.name AS type_name
     FROM users u
     LEFT JOIN personnel_types t ON t.id = u.type_id
     WHERE u.id = ? AND u.role = 'technicien'`,
  ).get(id);
  if (!row) fail('Personnel introuvable', 404);
  return row;
}

function serialize(row) {
  return {
    id: row.id,
    firstName: row.first_name,
    lastName: row.last_name,
    name: row.name,
    typeId: row.type_id,
    typeName: row.type_name ?? '',
    quota: row.quota,
    arrivalDate: row.arrival_date,
    active: row.active === 1,
    planningNotes: row.planning_notes ?? '',
    loginId: row.email,
  };
}

function parsePerson(body, { requirePassword, currentId = 0 }) {
  const firstName = String(body?.firstName ?? '').trim();
  const lastName = String(body?.lastName ?? '').trim();
  const typeId = Number(body?.typeId);
  const quota = Number(body?.quota);
  const arrivalDate = String(body?.arrivalDate ?? '').trim();
  const active = body?.active === false ? 0 : 1;
  const planningNotes = String(body?.planningNotes ?? '').trim();
  const loginId = String(body?.loginId ?? '').trim().toLowerCase();
  const password = String(body?.password ?? '');

  if (!lastName || lastName.length > 40) fail('Indiquez le nom', 400);
  if (!firstName || firstName.length > 40) fail('Indiquez le prénom', 400);
  if (!LOGIN.test(loginId)) fail('Indiquez un identifiant de 3 à 64 caractères', 400);
  if (requirePassword || password) {
    if (password.length < 4 || password.length > 72) fail('Le mot de passe doit contenir au moins 4 caractères', 400);
  }
  if (!Number.isInteger(quota) || quota < 1 || quota > 100) fail('La quotité doit être entre 1 et 100 %', 400);
  if (!DATE.test(arrivalDate)) fail('Indiquez la date d’arrivée', 400);
  if (planningNotes.length > 300) fail('Les informations de planification sont trop longues', 400);
  const taken = db.prepare(`SELECT id FROM users WHERE (email = ? OR login_id = ?) AND id != ?`).get(loginId, loginId, currentId);
  if (taken) fail('Cet identifiant est déjà utilisé', 409);
  const type = readType(typeId);
  return { firstName, lastName, type, quota, arrivalDate, active, planningNotes, loginId, password };
}

function clearFutureWork(userId) {
  const today = isoDate(new Date());
  db.prepare(
    `UPDATE assignments SET code = 'R.H.'
     WHERE user_id = ? AND date >= ? AND code NOT IN (${OFF.map(() => '?').join(', ')})`,
  ).run(userId, today, ...OFF);
}

function historyCount(userId) {
  const assignments = db.prepare(`SELECT COUNT(*) AS count FROM assignments WHERE user_id = ?`).get(userId);
  const requests = db.prepare(`SELECT COUNT(*) AS count FROM requests WHERE user_id = ?`).get(userId);
  return assignments.count + requests.count;
}

export function listTypes(user) {
  requireCadre(user);
  return db.prepare(
    `SELECT t.id, t.name, COUNT(u.id) AS used
     FROM personnel_types t
     LEFT JOIN users u ON u.type_id = t.id
     GROUP BY t.id
     ORDER BY t.name`,
  ).all().map((row) => ({ id: row.id, name: row.name, used: row.used }));
}

export function createType(user, body) {
  requireCadre(user);
  const name = String(body?.name ?? '').trim();
  if (!name || name.length > 40) fail('Indiquez le nom de la catégorie', 400);
  try {
    const result = db.prepare(`INSERT INTO personnel_types (name) VALUES (?)`).run(name);
    return { id: Number(result.lastInsertRowid), name, used: 0 };
  } catch {
    fail('Cette catégorie existe déjà', 409);
  }
}

export function updateType(user, id, body) {
  requireCadre(user);
  const current = readType(id);
  const name = String(body?.name ?? '').trim();
  if (!name || name.length > 40) fail('Indiquez le nom de la catégorie', 400);
  try {
    db.prepare(`UPDATE personnel_types SET name = ? WHERE id = ?`).run(name, current.id);
  } catch {
    fail('Cette catégorie existe déjà', 409);
  }
  db.prepare(`UPDATE users SET job_title = ? WHERE type_id = ?`).run(name, current.id);
  return listTypes(user).find((type) => type.id === current.id);
}

export function deleteType(user, id) {
  requireCadre(user);
  const current = readType(id);
  const used = db.prepare(`SELECT COUNT(*) AS count FROM users WHERE type_id = ?`).get(current.id);
  if (used.count > 0) fail('Cette catégorie est utilisée', 409);
  const total = db.prepare(`SELECT COUNT(*) AS count FROM personnel_types`).get();
  if (total.count <= 1) fail('Conservez au moins une catégorie', 400);
  db.prepare(`DELETE FROM personnel_types WHERE id = ?`).run(current.id);
  return { ok: true };
}

export function listPersonnel(user) {
  requireCadre(user);
  return db.prepare(
    `SELECT u.*, t.name AS type_name
     FROM users u
     LEFT JOIN personnel_types t ON t.id = u.type_id
     WHERE u.role = 'technicien'
     ORDER BY u.active DESC, u.last_name, u.first_name`,
  ).all().map(serialize);
}

export function getPersonnel(user, id) {
  requireCadre(user);
  const person = readPerson(id);
  const granted = new Set(
    db.prepare(
      `SELECT post_id FROM habilitations
       WHERE user_id = ? AND status IN ('Habilité', 'Expire bientôt')`,
    ).all(id).map((row) => row.post_id),
  );
  const posts = db.prepare(`SELECT id, code, name, active FROM posts ORDER BY active DESC, name`).all().map((post) => ({
    id: post.id,
    code: post.code,
    name: post.name,
    active: post.active === 1,
    enabled: granted.has(post.id),
  }));
  return { ...serialize(person), posts };
}

export function createPersonnel(user, body) {
  requireCadre(user);
  const fields = parsePerson(body, { requirePassword: true });
  const name = `${fields.firstName} ${fields.lastName}`;
  const result = db.prepare(
    `INSERT INTO users (
       email, password_hash, name, role, job_title, contract, lab_name,
       first_name, last_name, type_id, quota, arrival_date, active, planning_notes, login_id
     ) VALUES (?, ?, ?, 'technicien', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    fields.loginId,
    hashPassword(fields.password),
    name,
    fields.type.name,
    `${fields.quota}%`,
    user.lab_name,
    fields.firstName,
    fields.lastName,
    fields.type.id,
    fields.quota,
    fields.arrivalDate,
    fields.active,
    fields.planningNotes,
    fields.loginId,
  );
  const id = Number(result.lastInsertRowid);
  db.prepare(
    `INSERT INTO leave_balances (user_id, ca_remaining, ca_total, rtt_remaining, rtt_total)
     VALUES (?, 25, 25, 10, 10)`,
  ).run(id);
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
    user.id,
    `Personnel ajouté — ${name}`,
    new Date().toISOString(),
  );
  return getPersonnel(user, id);
}

export function updatePersonnel(user, id, body) {
  requireCadre(user);
  const current = readPerson(id);
  const fields = parsePerson(body, { requirePassword: false, currentId: current.id });
  const name = `${fields.firstName} ${fields.lastName}`;
  db.exec('BEGIN');
  try {
    db.prepare(
      `UPDATE users
       SET email = ?, login_id = ?, name = ?, job_title = ?, contract = ?, first_name = ?, last_name = ?, type_id = ?,
           quota = ?, arrival_date = ?, active = ?, planning_notes = ?
       WHERE id = ?`,
    ).run(
      fields.loginId,
      fields.loginId,
      name,
      fields.type.name,
      `${fields.quota}%`,
      fields.firstName,
      fields.lastName,
      fields.type.id,
      fields.quota,
      fields.arrivalDate,
      fields.active,
      fields.planningNotes,
      current.id,
    );
    if (fields.password) {
      db.prepare(`UPDATE users SET password_hash = ? WHERE id = ?`).run(hashPassword(fields.password), current.id);
      db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(current.id);
    }
    if (current.active === 1 && fields.active === 0) clearFutureWork(current.id);
    db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
      user.id,
      `Personnel modifié — ${name}`,
      new Date().toISOString(),
    );
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
  return getPersonnel(user, id);
}

export function deletePersonnel(user, id) {
  requireCadre(user);
  const current = readPerson(id);
  if (historyCount(current.id) > 0) {
    fail('Ce personnel a un historique de planning. Désactivez-le pour le retirer du planning actuel.', 409);
  }
  db.exec('BEGIN');
  try {
    db.prepare(`DELETE FROM habilitations WHERE user_id = ?`).run(current.id);
    db.prepare(`DELETE FROM leave_balances WHERE user_id = ?`).run(current.id);
    db.prepare(`DELETE FROM activity WHERE user_id = ?`).run(current.id);
    db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(current.id);
    db.prepare(`DELETE FROM users WHERE id = ?`).run(current.id);
    db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
      user.id,
      `Personnel supprimé — ${current.name}`,
      new Date().toISOString(),
    );
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
  return { ok: true };
}
