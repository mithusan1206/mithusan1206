import { db } from './db.js';
import { eachDate, formatRange, frTime, isoDate, parseIso, shortDay } from './dates.js';
import { isHoliday, isWeekend } from './holidays.js';

const OFF = new Set(['R.H.', 'CA', 'RTT', 'J.F.', 'ABS']);
const SWAPPABLE = new Set(['CA', 'RTT']);
const HABILITATED = new Set(['Habilité', 'Expire bientôt']);

function fail(message, status) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function isWork(code) {
  return Boolean(code) && !OFF.has(code);
}

function firstName(user) {
  return user.first_name || String(user.name).split(' ')[0];
}

function postHours(code) {
  if (!isWork(code)) return '';
  const post = db.prepare(`SELECT start_time, end_time FROM posts WHERE code = ? AND active = 1`).get(code);
  if (!post) return '';
  return `${frTime(post.start_time)}–${frTime(post.end_time)}`;
}

function qualified(userId, code) {
  if (!isWork(code)) return true;
  const row = db.prepare(
    `SELECT h.status FROM habilitations h
     JOIN posts p ON p.id = h.post_id
     WHERE h.user_id = ? AND p.code = ? AND p.active = 1`,
  ).get(userId, code);
  return Boolean(row && HABILITATED.has(row.status));
}

function monthWindow(date) {
  const from = isoDate(new Date(date.getFullYear(), date.getMonth(), 1));
  const last = new Date(date.getFullYear(), date.getMonth() + 1, 0);
  let working = 0;
  for (let day = 1; day <= last.getDate(); day += 1) {
    const cursor = new Date(date.getFullYear(), date.getMonth(), day);
    if (!isWeekend(cursor) && !isHoliday(cursor)) working += 1;
  }
  return { from, to: isoDate(last), working };
}

function workDays(userId, from, to, exceptDates) {
  const skipped = exceptDates instanceof Set ? exceptDates : new Set(exceptDates ? [exceptDates] : []);
  return db.prepare(
    `SELECT date, code FROM assignments WHERE user_id = ? AND date >= ? AND date <= ?`,
  ).all(userId, from, to).filter((row) => !skipped.has(row.date) && isWork(row.code)).length;
}

function swappable(code) {
  return isWork(code) || SWAPPABLE.has(code);
}

function hasAbsence(userId, date) {
  return Boolean(db.prepare(
    `SELECT id FROM requests
     WHERE user_id = ? AND type = 'Absence' AND status IN ('En attente', 'Validée')
       AND start_date <= ? AND end_date >= ?`,
  ).get(userId, date, date));
}

export function evaluateExchange(requester, partner, date, requesterCode, partnerCode) {
  const issues = [];
  const day = parseIso(date);
  const requesterName = firstName(requester);
  const partnerName = firstName(partner);

  if (!requesterCode || !partnerCode) issues.push('Le planning de cette date est incomplet.');
  if (OFF.has(requesterCode) && !SWAPPABLE.has(requesterCode)) {
    issues.push(`${requesterName} n'a pas un poste, un CA ou un RTT à échanger ce jour-là.`);
  }
  if (OFF.has(partnerCode) && !SWAPPABLE.has(partnerCode)) {
    issues.push(`${partnerName} n'a pas un poste, un CA ou un RTT à échanger ce jour-là.`);
  }
  if (requesterCode === 'ABS' || partnerCode === 'ABS' || hasAbsence(requester.id, date) || hasAbsence(partner.id, date)) {
    issues.push('Une absence est déjà déclarée sur cette date.');
  }
  if ((isWeekend(day) || isHoliday(day)) && (isWork(requesterCode) || isWork(partnerCode))) {
    issues.push('Règle du laboratoire : un poste ne s’échange pas un jour de repos.');
  }
  if (isWork(partnerCode) && !qualified(requester.id, partnerCode)) {
    issues.push(`${requesterName} n'est pas habilité pour ${partnerCode}.`);
  }
  if (isWork(requesterCode) && !qualified(partner.id, requesterCode)) {
    issues.push(`${partnerName} n'est pas habilité pour ${requesterCode}.`);
  }

  for (const [person, giving, receiving] of [
    [requester, requesterCode, partnerCode],
    [partner, partnerCode, requesterCode],
  ]) {
    if (isWork(receiving) && !isWork(giving) && /repos/i.test(person.planning_notes ?? '')) {
      issues.push(`Contrainte de planning pour ${firstName(person)} : ${person.planning_notes}`);
    }
  }

  return issues;
}

function rangeTotals(requester, partner, days) {
  const issues = [];
  for (const person of [requester, partner]) {
    const gained = new Map();
    let ca = 0;
    let rtt = 0;
    for (const day of days) {
      const giving = person.id === requester.id ? day.requesterCode : day.partnerCode;
      const receiving = person.id === requester.id ? day.partnerCode : day.requesterCode;
      if (isWork(receiving) && !isWork(giving)) {
        const key = day.date.slice(0, 7);
        gained.set(key, [...(gained.get(key) ?? []), day.date]);
      }
      if (receiving === 'CA' && giving !== 'CA') ca += 1;
      if (giving === 'CA' && receiving !== 'CA') ca -= 1;
      if (receiving === 'RTT' && giving !== 'RTT') rtt += 1;
      if (giving === 'RTT' && receiving !== 'RTT') rtt -= 1;
    }
    for (const dates of gained.values()) {
      const window = monthWindow(parseIso(dates[0]));
      const cap = Math.round(window.working * Number(person.quota ?? 100) / 100);
      const projected = workDays(person.id, window.from, window.to, new Set(dates)) + dates.length;
      if (projected > cap) issues.push(`${firstName(person)} dépasserait sa quotité de ${person.quota} %.`);
    }
    const balance = db.prepare(`SELECT ca_remaining, rtt_remaining FROM leave_balances WHERE user_id = ?`).get(person.id);
    if ((balance?.ca_remaining ?? 0) < ca) issues.push(`Solde de CA insuffisant pour ${firstName(person)}.`);
    if ((balance?.rtt_remaining ?? 0) < rtt) issues.push(`Solde de RTT insuffisant pour ${firstName(person)}.`);
  }
  return issues;
}

function reviewDays(requester, partner, days) {
  const issues = [];
  for (const day of days) {
    issues.push(...evaluateExchange(requester, partner, day.date, day.requesterCode, day.partnerCode));
  }
  issues.push(...rangeTotals(requester, partner, days));
  return issues;
}

function proposedDays(requester, partner, start, end) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end) || start > end) {
    fail('Choisissez une date de début puis une date de fin', 400);
  }
  const dates = eachDate(start, end);
  if (dates.length > 31) fail('La période ne peut pas dépasser 31 jours', 400);
  if (dates[0] < isoDate(new Date())) fail('Choisissez aujourd’hui ou une date à venir', 400);
  const days = [];
  for (const date of dates) {
    const requesterCode = assignmentCode(requester.id, date);
    const partnerCode = assignmentCode(partner.id, date);
    if (!swappable(requesterCode) && !swappable(partnerCode)) continue;
    days.push({ date, requesterCode, partnerCode });
  }
  if (!days.length) fail('Aucun poste, CA ou RTT à échanger sur cette période', 409);
  return days;
}

function storedDays(row) {
  if (row.exchange_days) {
    try {
      const parsed = JSON.parse(row.exchange_days);
      if (Array.isArray(parsed) && parsed.length) return parsed;
    } catch {
      /* fall back to the single stored day */
    }
  }
  return [{ date: row.start_date, requesterCode: row.requester_code, partnerCode: row.partner_code }];
}

function matchesPlanning(days, requesterId, partnerId) {
  return days.every((day) => (
    assignmentCode(requesterId, day.date) === day.requesterCode
    && assignmentCode(partnerId, day.date) === day.partnerCode
  ));
}

function assignmentCode(userId, date) {
  return db.prepare(`SELECT code FROM assignments WHERE user_id = ? AND date = ?`).get(userId, date)?.code ?? '';
}

function loadTech(id) {
  const user = db.prepare(
    `SELECT * FROM users WHERE id = ? AND role = 'technicien' AND active = 1`,
  ).get(id);
  if (!user) fail('Technicien introuvable', 404);
  return user;
}

export function exchangeOptions(user, date) {
  if (user.role !== 'technicien') fail('Réservé aux techniciens', 403);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date < isoDate(new Date())) {
    fail('Choisissez aujourd’hui ou une date à venir', 400);
  }
  const ownCode = assignmentCode(user.id, date);
  const partners = db.prepare(
    `SELECT u.id, u.name, u.first_name, a.code
     FROM users u
     JOIN assignments a ON a.user_id = u.id AND a.date = ?
     WHERE u.role = 'technicien' AND u.active = 1 AND u.id != ?
     ORDER BY u.name`,
  ).all(date, user.id).filter((row) => isWork(row.code) || SWAPPABLE.has(row.code));
  return {
    ownCode,
    canAsk: isWork(ownCode) || SWAPPABLE.has(ownCode),
    partners: partners.map((row) => ({
      id: row.id,
      name: row.name,
      code: row.code,
      hours: postHours(row.code),
    })),
  };
}

export function createExchange(user, body) {
  if (user.role !== 'technicien') fail('Réservé aux techniciens', 403);
  const start = String(body?.startDate || body?.date || '');
  const end = String(body?.endDate || body?.date || start);
  const partner = loadTech(Number(body?.partnerId));
  const reason = String(body?.reason ?? '').trim() || 'Échange de poste';
  if (reason.length > 200) fail('Le motif est trop long', 400);
  if (partner.id === user.id) fail('Choisissez un autre technicien', 400);
  const requester = loadTech(user.id);
  const days = proposedDays(requester, partner, start, end);
  const open = db.prepare(
    `SELECT id FROM requests
     WHERE type = 'Échange' AND status IN ('En attente du collègue', 'En attente')
       AND start_date <= ? AND end_date >= ?
       AND (user_id = ? OR partner_id = ? OR user_id = ? OR partner_id = ?)`,
  ).get(end, start, requester.id, requester.id, partner.id, partner.id);
  if (open) fail('Un échange est déjà en cours sur cette période', 409);

  const issues = reviewDays(requester, partner, days);
  if (issues.length) fail(issues[0], 409);

  const now = new Date().toISOString();
  const first = days[0];
  const result = db.prepare(
    `INSERT INTO requests (
       user_id, type, start_date, end_date, reason, status, created_at,
       partner_id, requester_code, partner_code, partner_status, exchange_days
     ) VALUES (?, 'Échange', ?, ?, ?, 'En attente du collègue', ?, ?, ?, ?, 'en attente', ?)`,
  ).run(
    requester.id, start, end, reason, now, partner.id,
    first.requesterCode, first.partnerCode, JSON.stringify(days),
  );
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
    requester.id,
    `Demande d'échange — ${firstName(partner)} du ${start} au ${end}`,
    now,
  );
  return { id: Number(result.lastInsertRowid) };
}

function notifyCadres(action, now) {
  const cadres = db.prepare(`SELECT id FROM users WHERE role = 'cadre'`).all();
  for (const cadre of cadres) {
    db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(cadre.id, action, now);
  }
}

export function updateExchange(user, requestId, body) {
  if (user.role !== 'technicien') fail('Réservé aux techniciens', 403);
  const row = db.prepare(`SELECT * FROM requests WHERE id = ? AND type = 'Échange'`).get(requestId);
  if (!row || row.user_id !== user.id) fail('Demande introuvable', 404);
  if (row.status !== 'En attente du collègue' && row.status !== 'En attente') {
    fail('Cette demande ne peut plus être modifiée', 409);
  }
  const start = String(body?.startDate || '');
  const end = String(body?.endDate || start);
  const reason = String(body?.reason ?? '').trim() || 'Échange de poste';
  if (reason.length > 200) fail('Le motif est trop long', 400);
  const requester = loadTech(user.id);
  const partner = loadTech(row.partner_id);
  const days = proposedDays(requester, partner, start, end);
  const open = db.prepare(
    `SELECT id FROM requests
     WHERE type = 'Échange' AND id != ? AND status IN ('En attente du collègue', 'En attente')
       AND start_date <= ? AND end_date >= ?
       AND (user_id = ? OR partner_id = ? OR user_id = ? OR partner_id = ?)`,
  ).get(row.id, end, start, requester.id, requester.id, partner.id, partner.id);
  if (open) fail('Un échange est déjà en cours sur cette période', 409);
  const issues = reviewDays(requester, partner, days);
  if (issues.length) fail(issues[0], 409);

  const status = row.partner_status === 'acceptée' ? 'En attente' : row.status;
  const partnerStatus = row.partner_status === 'acceptée' ? 'acceptée' : 'en attente';
  const now = new Date().toISOString();
  const first = days[0];
  db.prepare(
    `UPDATE requests
     SET start_date = ?, end_date = ?, reason = ?, status = ?, partner_status = ?,
         requester_code = ?, partner_code = ?, exchange_days = ?
     WHERE id = ?`,
  ).run(start, end, reason, status, partnerStatus, first.requesterCode, first.partnerCode, JSON.stringify(days), row.id);
  const label = `Échange modifié — ${firstName(requester)} / ${firstName(partner)} du ${start} au ${end}`;
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(requester.id, label, now);
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(partner.id, label, now);
  notifyCadres(label, now);
  return { id: row.id };
}

export function deleteExchange(user, requestId) {
  if (user.role !== 'technicien') fail('Réservé aux techniciens', 403);
  const row = db.prepare(`SELECT * FROM requests WHERE id = ? AND type = 'Échange'`).get(requestId);
  if (!row || row.user_id !== user.id) fail('Demande introuvable', 404);
  if (row.status !== 'En attente du collègue' && row.status !== 'En attente') {
    fail('Cette demande ne peut plus être supprimée', 409);
  }
  const requester = db.prepare(`SELECT * FROM users WHERE id = ?`).get(row.user_id);
  const partner = db.prepare(`SELECT * FROM users WHERE id = ?`).get(row.partner_id);
  const now = new Date().toISOString();
  const label = `Échange annulé — ${firstName(requester)} / ${firstName(partner)} du ${row.start_date} au ${row.end_date}`;
  db.prepare(`DELETE FROM requests WHERE id = ?`).run(row.id);
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(requester.id, label, now);
  if (partner) db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(partner.id, label, now);
  notifyCadres(label, now);
  return { ok: true };
}

export function replyExchange(user, requestId, action) {
  if (user.role !== 'technicien') fail('Réservé aux techniciens', 403);
  const row = db.prepare(`SELECT * FROM requests WHERE id = ? AND type = 'Échange'`).get(requestId);
  if (!row || row.partner_id !== user.id) fail('Demande introuvable', 404);
  if (row.status !== 'En attente du collègue') fail('Cette demande est déjà traitée', 409);
  const now = new Date().toISOString();
  if (action === 'refuse') {
    db.prepare(
      `UPDATE requests SET status = 'Refusée', partner_status = 'refusée', resolved_at = ?, resolved_by = ? WHERE id = ?`,
    ).run(now, user.id, row.id);
    return { ok: true };
  }
  if (action !== 'accept') fail('Action invalide', 400);
  const requester = loadTech(row.user_id);
  const partner = loadTech(row.partner_id);
  const days = storedDays(row);
  if (!matchesPlanning(days, requester.id, partner.id)) fail('Le planning a changé depuis la demande', 409);
  const issues = reviewDays(requester, partner, days);
  if (issues.length) fail(issues[0], 409);
  db.prepare(
    `UPDATE requests SET status = 'En attente', partner_status = 'acceptée' WHERE id = ?`,
  ).run(row.id);
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
    partner.id,
    `Échange accepté — en attente du cadre`,
    now,
  );
  return { ok: true };
}

function setCode(userId, date, code) {
  const updated = db.prepare(`UPDATE assignments SET code = ? WHERE user_id = ? AND date = ?`).run(code, userId, date);
  if (updated.changes === 0) {
    db.prepare(`INSERT INTO assignments (user_id, date, code) VALUES (?, ?, ?)`).run(userId, date, code);
  }
}

function moveBalance(userId, field, delta) {
  if (!delta) return;
  db.prepare(`UPDATE leave_balances SET ${field} = ${field} + ? WHERE user_id = ?`).run(delta, userId);
}

export function settleExchange(actor, row, action) {
  if (actor.role !== 'cadre') fail('Réservé au cadre de santé', 403);
  if (row.status !== 'En attente' || row.partner_status !== 'acceptée') {
    fail('Le collègue n’a pas encore accepté cet échange', 409);
  }
  const requester = db.prepare(`SELECT * FROM users WHERE id = ?`).get(row.user_id);
  const partner = db.prepare(`SELECT * FROM users WHERE id = ?`).get(row.partner_id);
  const now = new Date().toISOString();
  if (action === 'reject') {
    db.prepare(
      `UPDATE requests SET status = 'Refusée', resolved_at = ?, resolved_by = ? WHERE id = ?`,
    ).run(now, actor.id, row.id);
    db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
      actor.id, `Échange refusé — ${requester.name} / ${partner.name}`, now,
    );
    return;
  }
  const days = storedDays(row);
  if (!matchesPlanning(days, requester.id, partner.id)) fail('Le planning a changé depuis la demande', 409);
  const issues = reviewDays(requester, partner, days);
  if (issues.length) fail(issues.join(' '), 409);

  db.exec('BEGIN');
  try {
    for (const day of days) {
      setCode(requester.id, day.date, day.partnerCode);
      setCode(partner.id, day.date, day.requesterCode);
      if (day.requesterCode === 'CA' && day.partnerCode !== 'CA') moveBalance(requester.id, 'ca_remaining', 1);
      if (day.partnerCode === 'CA' && day.requesterCode !== 'CA') moveBalance(requester.id, 'ca_remaining', -1);
      if (day.requesterCode === 'RTT' && day.partnerCode !== 'RTT') moveBalance(requester.id, 'rtt_remaining', 1);
      if (day.partnerCode === 'RTT' && day.requesterCode !== 'RTT') moveBalance(requester.id, 'rtt_remaining', -1);
      if (day.partnerCode === 'CA' && day.requesterCode !== 'CA') moveBalance(partner.id, 'ca_remaining', 1);
      if (day.requesterCode === 'CA' && day.partnerCode !== 'CA') moveBalance(partner.id, 'ca_remaining', -1);
      if (day.partnerCode === 'RTT' && day.requesterCode !== 'RTT') moveBalance(partner.id, 'rtt_remaining', 1);
      if (day.requesterCode === 'RTT' && day.partnerCode !== 'RTT') moveBalance(partner.id, 'rtt_remaining', -1);
    }
    db.prepare(
      `UPDATE requests SET status = 'Validée', resolved_at = ?, resolved_by = ? WHERE id = ?`,
    ).run(now, actor.id, row.id);
    const label = `Échange validé — ${firstName(requester)} / ${firstName(partner)} du ${row.start_date} au ${row.end_date}`;
    for (const id of [actor.id, requester.id, partner.id]) {
      db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(id, label, now);
    }
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

export function reapplyExchanges(from, to) {
  const rows = db.prepare(
    `SELECT * FROM requests
     WHERE type = 'Échange' AND status = 'Validée' AND partner_id IS NOT NULL
       AND start_date <= ? AND end_date >= ?`,
  ).all(to, from);
  for (const row of rows) {
    for (const day of storedDays(row)) {
      if (day.date < from || day.date > to) continue;
      if (isWork(day.partnerCode)) {
        db.prepare(
          `UPDATE assignments SET code = 'R.H.' WHERE date = ? AND code = ? AND user_id != ?`,
        ).run(day.date, day.partnerCode, row.user_id);
      }
      if (isWork(day.requesterCode)) {
        db.prepare(
          `UPDATE assignments SET code = 'R.H.' WHERE date = ? AND code = ? AND user_id != ?`,
        ).run(day.date, day.requesterCode, row.partner_id);
      }
      setCode(row.user_id, day.date, day.partnerCode);
      setCode(row.partner_id, day.date, day.requesterCode);
    }
  }
}

export function exchangeView(row) {
  if (row.type !== 'Échange' || !row.partner_id) return null;
  const partner = db.prepare(`SELECT name, first_name FROM users WHERE id = ?`).get(row.partner_id);
  const requester = db.prepare(`SELECT name, first_name FROM users WHERE id = ?`).get(row.user_id);
  const days = storedDays(row);
  const first = days[0];
  const focus = isWork(first.requesterCode) ? first.requesterCode : first.partnerCode;
  const hours = days.length === 1 ? postHours(focus) : '';
  return {
    fromName: firstName(requester),
    toName: firstName(partner),
    dateLabel: formatRange(row.start_date, row.end_date),
    focusLabel: days.length === 1 ? (hours ? `${focus} — ${hours}` : focus) : `${days.length} jours`,
    fromCode: first.requesterCode,
    toCode: first.partnerCode,
    days: days.map((day) => ({
      dateLabel: shortDay(day.date),
      fromCode: day.requesterCode,
      toCode: day.partnerCode,
    })),
    partnerId: row.partner_id,
    startDate: row.start_date,
    endDate: row.end_date,
    colleagueAccepted: row.partner_status === 'acceptée',
    waitingColleague: row.status === 'En attente du collègue',
  };
}
