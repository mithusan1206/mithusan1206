import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import cors from 'cors';
import express from 'express';
import { accountFor, changeLoginId, changePassword } from './account.js';
import { createExchange, deleteExchange, exchangeOptions, replyExchange, updateExchange } from './exchanges.js';
import { db, ensureSchema } from './db.js';
import { seedIfEmpty } from './seed.js';
import { generateRange, regenerateDemoWindow } from './planning.js';
import {
  createPersonnel,
  createType,
  deletePersonnel,
  deleteType,
  getPersonnel,
  listPersonnel,
  listTypes,
  updatePersonnel,
  updateType,
} from './personnel.js';
import {
  createPost,
  deletePost,
  getPost,
  listPosts,
  setHabilitation,
  updatePost,
} from './posts.js';
import {
  dashboardFor,
  decideRequest,
  mePayload,
  planningFor,
  profileFor,
  recordPlanningActivity,
  requestsFor,
  teamFor,
} from './queries.js';

const { postsReset } = ensureSchema();
seedIfEmpty();
if (postsReset) regenerateDemoWindow();

const app = express();
app.use(cors());
app.use(express.json());

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const next = scryptSync(password, salt, 32);
  const prev = Buffer.from(hash, 'hex');
  return next.length === prev.length && timingSafeEqual(next, prev);
}

function auth(req, res, next) {
  const header = req.headers.authorization ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const session = token
    ? db.prepare(`SELECT user_id, created_at FROM sessions WHERE token = ?`).get(token)
    : undefined;
  if (!session) return res.status(401).json({ error: 'Authentification requise' });
  const age = Date.now() - new Date(session.created_at).getTime();
  if (age > 30 * 24 * 3600 * 1000) {
    db.prepare(`DELETE FROM sessions WHERE token = ?`).run(token);
    return res.status(401).json({ error: 'Session expirée' });
  }
  req.user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(session.user_id);
  if (!req.user) return res.status(401).json({ error: 'Authentification requise' });
  next();
}

function fail(res, error) {
  const status = error.status ?? 500;
  if (status === 500) console.error(error);
  res.status(status).json({ error: status === 500 ? 'Erreur interne' : error.message });
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

app.post('/api/auth/login', (req, res) => {
  const email = String(req.body?.email ?? '').trim().toLowerCase();
  const password = String(req.body?.password ?? '');
  const user = db.prepare(`SELECT * FROM users WHERE login_id = ?`).get(email)
    ?? db.prepare(`SELECT * FROM users WHERE email = ?`).get(email);
  if (!user || user.active === 0 || !verifyPassword(password, user.password_hash)) {
    return res.status(401).json({ error: 'Identifiants incorrects' });
  }
  const token = randomBytes(32).toString('hex');
  db.prepare(`INSERT INTO sessions (token, user_id, created_at) VALUES (?, ?, ?)`).run(
    token, user.id, new Date().toISOString(),
  );
  res.json({ token, user: mePayload(user) });
});

app.delete('/api/auth/session', auth, (req, res) => {
  const token = (req.headers.authorization ?? '').slice(7);
  db.prepare(`DELETE FROM sessions WHERE token = ?`).run(token);
  res.json({ ok: true });
});

app.get('/api/me', auth, (req, res) => {
  res.json({ user: mePayload(req.user) });
});

app.get('/api/account', auth, (req, res) => {
  try {
    res.json(accountFor(req.user));
  } catch (error) {
    fail(res, error);
  }
});

app.patch('/api/account/login', auth, (req, res) => {
  try {
    res.json(changeLoginId(req.user, req.body?.loginId));
  } catch (error) {
    fail(res, error);
  }
});

app.post('/api/account/password', auth, (req, res) => {
  try {
    res.json(changePassword(req.user, req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/dashboard', auth, (req, res) => {
  res.json(dashboardFor(req.user));
});

app.get('/api/planning', auth, (req, res) => {
  const from = String(req.query.from ?? '');
  const to = String(req.query.to ?? '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || from > to) {
    return res.status(400).json({ error: 'Période invalide' });
  }
  res.json(planningFor(req.user, from, to));
});

app.post('/api/planning/generate', auth, (req, res) => {
  try {
    if (req.user.role !== 'cadre') {
      return res.status(403).json({ error: 'Réservé au cadre de santé' });
    }
    const from = String(req.body?.from ?? '');
    const to = String(req.body?.to ?? '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || from > to) {
      return res.status(400).json({ error: 'Période invalide' });
    }
    generateRange(from, to);
    recordPlanningActivity(req.user, from, to);
    res.json(planningFor(req.user, from, to));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/team', auth, (req, res) => {
  res.json(teamFor(String(req.query.q ?? ''), String(req.query.filter ?? 'Tous')));
});

app.get('/api/team/:id', auth, (req, res) => {
  try {
    res.json(profileFor(req.user, Number(req.params.id)));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/requests', auth, (req, res) => {
  res.json(requestsFor(req.user, String(req.query.category ?? 'Tout')));
});

app.get('/api/exchanges/options', auth, (req, res) => {
  try {
    res.json(exchangeOptions(req.user, String(req.query.date ?? '')));
  } catch (error) {
    fail(res, error);
  }
});

app.post('/api/exchanges', auth, (req, res) => {
  try {
    res.status(201).json(createExchange(req.user, req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.patch('/api/exchanges/:id', auth, (req, res) => {
  try {
    res.json(updateExchange(req.user, Number(req.params.id), req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.delete('/api/exchanges/:id', auth, (req, res) => {
  try {
    res.json(deleteExchange(req.user, Number(req.params.id)));
  } catch (error) {
    fail(res, error);
  }
});

app.post('/api/exchanges/:id/reply', auth, (req, res) => {
  try {
    const action = req.body?.action === 'accept' ? 'accept' : req.body?.action === 'refuse' ? 'refuse' : '';
    if (!action) return res.status(400).json({ error: 'Action invalide' });
    res.json(replyExchange(req.user, Number(req.params.id), action));
  } catch (error) {
    fail(res, error);
  }
});

app.post('/api/requests/:id/decision', auth, (req, res) => {
  try {
    const action = req.body?.action === 'reject' ? 'reject' : req.body?.action === 'approve' ? 'approve' : '';
    if (!action) return res.status(400).json({ error: 'Action invalide' });
    res.json(decideRequest(req.user, Number(req.params.id), action));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/profile', auth, (req, res) => {
  try {
    res.json(profileFor(req.user, req.user.id));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/posts', auth, (req, res) => {
  res.json({ posts: listPosts(req.user) });
});

app.post('/api/posts', auth, (req, res) => {
  try {
    res.status(201).json(createPost(req.user, req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/posts/:id', auth, (req, res) => {
  try {
    res.json(getPost(req.user, Number(req.params.id)));
  } catch (error) {
    fail(res, error);
  }
});

app.patch('/api/posts/:id', auth, (req, res) => {
  try {
    res.json(updatePost(req.user, Number(req.params.id), req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.delete('/api/posts/:id', auth, (req, res) => {
  try {
    res.json(deletePost(req.user, Number(req.params.id)));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/personnel-types', auth, (req, res) => {
  try {
    res.json({ types: listTypes(req.user) });
  } catch (error) {
    fail(res, error);
  }
});

app.post('/api/personnel-types', auth, (req, res) => {
  try {
    res.status(201).json(createType(req.user, req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.patch('/api/personnel-types/:id', auth, (req, res) => {
  try {
    res.json(updateType(req.user, Number(req.params.id), req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.delete('/api/personnel-types/:id', auth, (req, res) => {
  try {
    res.json(deleteType(req.user, Number(req.params.id)));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/personnel', auth, (req, res) => {
  try {
    res.json({ personnel: listPersonnel(req.user) });
  } catch (error) {
    fail(res, error);
  }
});

app.post('/api/personnel', auth, (req, res) => {
  try {
    res.status(201).json(createPersonnel(req.user, req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.get('/api/personnel/:id', auth, (req, res) => {
  try {
    res.json(getPersonnel(req.user, Number(req.params.id)));
  } catch (error) {
    fail(res, error);
  }
});

app.patch('/api/personnel/:id', auth, (req, res) => {
  try {
    res.json(updatePersonnel(req.user, Number(req.params.id), req.body));
  } catch (error) {
    fail(res, error);
  }
});

app.delete('/api/personnel/:id', auth, (req, res) => {
  try {
    res.json(deletePersonnel(req.user, Number(req.params.id)));
  } catch (error) {
    fail(res, error);
  }
});

app.put('/api/habilitations', auth, (req, res) => {
  try {
    res.json(setHabilitation(req.user, req.body));
  } catch (error) {
    fail(res, error);
  }
});

const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'mobile', 'dist');
if (existsSync(dist)) {
  app.use(express.static(dist, {
    etag: false,
    lastModified: false,
    setHeaders(res) {
      res.setHeader('Cache-Control', 'no-store');
    },
  }));
  app.use((req, res, next) => {
    if (req.method !== 'GET' || req.path.startsWith('/api')) return next();
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(path.join(dist, 'index.html'));
  });
}

const port = Number(process.env.PORT || 3001);
app.listen(port, '0.0.0.0', () => {
  const addresses = Object.values(os.networkInterfaces())
    .flat()
    .filter((item) => item && item.family === 'IPv4' && !item.internal)
    .map((item) => `http://${item.address}:${port}`);
  console.log(`LAB API ready on http://localhost:${port}`);
  for (const address of addresses) console.log(`  phone: ${address}`);
  console.log('  cadre        martin@lab.chs            demo');
  console.log('  technicienne sophie.moreau@lab.chs     demo');
});
