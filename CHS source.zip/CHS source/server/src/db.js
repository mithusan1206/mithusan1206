import { mkdirSync } from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';

const dataDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data');
mkdirSync(dataDir, { recursive: true });

export const db = new DatabaseSync(path.join(dataDir, 'lab.db'));

function columnNames(table) {
  const exists = db.prepare(
    `SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?`,
  ).get(table);
  if (!exists) return [];
  return db.prepare(`PRAGMA table_info(${table})`).all().map((column) => column.name);
}

function resetLegacyPosts() {
  const columns = columnNames('posts');
  if (columns.length === 0 || columns.includes('name')) return false;
  db.exec('PRAGMA foreign_keys = OFF');
  db.exec('BEGIN');
  try {
    db.exec(`DELETE FROM assignments WHERE code NOT IN ('R.H.', 'CA', 'RTT', 'J.F.', 'ABS')`);
    db.exec(`UPDATE requests SET reason = 'Échange de poste avec P. Durand' WHERE reason = 'Échange JO avec P. Durand'`);
    db.exec(`DELETE FROM activity WHERE action LIKE '%Habilitation %'`);
    db.exec('DROP TABLE IF EXISTS habilitations');
    db.exec('DROP TABLE IF EXISTS posts');
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
  db.exec('PRAGMA foreign_keys = ON');
  return true;
}

export function ensureSchema() {
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
  `);
  const postsReset = resetLegacyPosts();
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('cadre', 'technicien')),
      job_title TEXT NOT NULL,
      contract TEXT NOT NULL,
      lab_name TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL DEFAULT '',
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      color TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      required_agents INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS habilitations (
      id INTEGER PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
      status TEXT NOT NULL,
      valid_until TEXT,
      UNIQUE(user_id, post_id)
    );

    CREATE TABLE IF NOT EXISTS assignments (
      id INTEGER PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      date TEXT NOT NULL,
      code TEXT NOT NULL,
      UNIQUE(user_id, date)
    );

    CREATE TABLE IF NOT EXISTS requests (
      id INTEGER PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      type TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL,
      created_at TEXT NOT NULL,
      resolved_at TEXT,
      resolved_by INTEGER REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS leave_balances (
      user_id INTEGER PRIMARY KEY REFERENCES users(id),
      ca_remaining INTEGER NOT NULL,
      ca_total INTEGER NOT NULL,
      rtt_remaining INTEGER NOT NULL,
      rtt_total INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS activity (
      id INTEGER PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      action TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL
    );
  `);
  ensurePersonnel();
  ensureExchangeColumns();
  return { postsReset };
}

function ensureExchangeColumns() {
  const columns = columnNames('requests');
  const add = (name, definition) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE requests ADD COLUMN ${definition}`);
  };
  add('partner_id', 'partner_id INTEGER REFERENCES users(id)');
  add('requester_code', `requester_code TEXT NOT NULL DEFAULT ''`);
  add('partner_code', `partner_code TEXT NOT NULL DEFAULT ''`);
  add('partner_status', `partner_status TEXT NOT NULL DEFAULT ''`);
  add('exchange_days', `exchange_days TEXT NOT NULL DEFAULT ''`);
}

const DEFAULT_TYPES = ['Technicien', 'Biologiste', 'Stagiaire', 'Aide-laboratoire', 'Cadre', 'Autre'];

function ensurePersonnel() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS personnel_types (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL UNIQUE
    );
  `);
  const insertType = db.prepare(`INSERT OR IGNORE INTO personnel_types (name) VALUES (?)`);
  for (const name of DEFAULT_TYPES) insertType.run(name);

  const columns = columnNames('users');
  const add = (name, definition) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE users ADD COLUMN ${definition}`);
  };
  add('first_name', `first_name TEXT NOT NULL DEFAULT ''`);
  add('last_name', `last_name TEXT NOT NULL DEFAULT ''`);
  add('type_id', `type_id INTEGER REFERENCES personnel_types(id)`);
  add('quota', `quota INTEGER NOT NULL DEFAULT 100`);
  add('arrival_date', `arrival_date TEXT NOT NULL DEFAULT ''`);
  add('active', `active INTEGER NOT NULL DEFAULT 1`);
  add('planning_notes', `planning_notes TEXT NOT NULL DEFAULT ''`);
  add('login_id', `login_id TEXT`);
  db.exec(`UPDATE users SET login_id = email WHERE login_id IS NULL OR login_id = ''`);
  db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS users_login_id ON users(login_id)`);
  backfillPersonnel();
}

export function backfillPersonnel() {
  const techType = db.prepare(`SELECT id FROM personnel_types WHERE name = 'Technicien'`).get();
  const cadreType = db.prepare(`SELECT id FROM personnel_types WHERE name = 'Cadre'`).get();
  if (!techType || !cadreType) return;
  const pending = db.prepare(
    `SELECT id, name, role, contract FROM users WHERE first_name = '' AND last_name = ''`,
  ).all();
  const update = db.prepare(
    `UPDATE users
     SET first_name = ?, last_name = ?, type_id = ?, quota = ?, arrival_date = ?, job_title = ?, contract = ?
     WHERE id = ?`,
  );
  for (const user of pending) {
    const parts = String(user.name).trim().split(/\s+/).filter(Boolean);
    const first = parts.length > 1 ? parts.slice(0, -1).join(' ') : (parts[0] ?? '');
    const last = parts.length > 1 ? parts[parts.length - 1] : (parts[0] ?? '');
    const match = String(user.contract ?? '').match(/(\d+)/);
    const quota = match ? Math.min(100, Math.max(1, Number(match[1]))) : 100;
    const type = user.role === 'cadre' ? cadreType : techType;
    update.run(first, last, type.id, quota, '2024-09-01', type.id === cadreType.id ? 'Cadre' : 'Technicien', `${quota}%`, user.id);
  }
}
