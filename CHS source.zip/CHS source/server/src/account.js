import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { db } from './db.js';

const LOGIN = /^[a-z0-9][a-z0-9._@-]{2,63}$/;

const PERMISSIONS = [
  'Administrateur du planning',
  'Gestion du personnel',
  'Habilitations',
  'Postes',
];

function fail(message, status) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function requireCadre(user) {
  if (user.role !== 'cadre') fail('Réservé au cadre de santé', 403);
}

function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 32).toString('hex');
  return `${salt}:${hash}`;
}

function passwordMatches(password, stored) {
  const [salt, hash] = String(stored ?? '').split(':');
  if (!salt || !hash) return false;
  const next = scryptSync(password, salt, 32);
  const prev = Buffer.from(hash, 'hex');
  return next.length === prev.length && timingSafeEqual(next, prev);
}

function fresh(id) {
  return db.prepare(`SELECT * FROM users WHERE id = ?`).get(id);
}

export function accountFor(user) {
  requireCadre(user);
  const row = fresh(user.id);
  return {
    firstName: row.first_name,
    lastName: row.last_name,
    name: row.name,
    roleLabel: 'Cadre de laboratoire',
    email: row.email,
    loginId: row.login_id || row.email,
    labName: row.lab_name,
    permissions: PERMISSIONS,
  };
}

export function changeLoginId(user, loginId) {
  requireCadre(user);
  const next = String(loginId ?? '').trim().toLowerCase();
  if (!LOGIN.test(next)) fail('Indiquez un identifiant de 3 à 64 caractères', 400);
  const taken = db.prepare(
    `SELECT id FROM users WHERE (login_id = ? OR email = ?) AND id != ?`,
  ).get(next, next, user.id);
  if (taken) fail('Cet identifiant est déjà utilisé', 409);
  db.prepare(`UPDATE users SET login_id = ? WHERE id = ? AND role = 'cadre'`).run(next, user.id);
  return accountFor(user);
}

export function changePassword(user, body) {
  requireCadre(user);
  const row = fresh(user.id);
  const current = String(body?.currentPassword ?? '');
  const next = String(body?.newPassword ?? '');
  if (!passwordMatches(current, row.password_hash)) fail('Ancien mot de passe incorrect', 400);
  if (next.length < 8 || next.length > 72) fail('Le nouveau mot de passe doit contenir au moins 8 caractères', 400);
  if (!/[A-Za-z]/.test(next) || !/\d/.test(next)) fail('Le mot de passe doit contenir une lettre et un chiffre', 400);
  if (next === current) fail('Choisissez un mot de passe différent de l’ancien', 400);
  db.prepare(`UPDATE users SET password_hash = ? WHERE id = ? AND role = 'cadre'`).run(hashPassword(next), user.id);
  return { ok: true };
}
