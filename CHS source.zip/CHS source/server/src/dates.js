const MONTHS = [
  'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
  'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre',
];
const MONTHS_SHORT = [
  'janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin',
  'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.',
];
const WEEKDAYS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];

export function isoDate(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseIso(value) {
  const [y, m, d] = value.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function addDays(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export function eachDate(from, to) {
  const dates = [];
  let cursor = parseIso(from);
  const end = parseIso(to);
  while (cursor <= end) {
    dates.push(isoDate(cursor));
    cursor = addDays(cursor, 1);
  }
  return dates;
}

export function todayIso() {
  return isoDate(new Date());
}

export function capital(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

export function longLabel(date) {
  return `${capital(WEEKDAYS[date.getDay()])} ${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

export function monthLabel(date) {
  return `${capital(MONTHS[date.getMonth()])} ${date.getFullYear()}`;
}

export function shortDay(iso) {
  const date = parseIso(iso);
  return `${date.getDate()} ${MONTHS_SHORT[date.getMonth()]} ${date.getFullYear()}`;
}

export function formatRange(start, end) {
  if (start === end) return shortDay(start);
  const a = parseIso(start);
  const b = parseIso(end);
  if (a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear()) {
    return `${a.getDate()}–${b.getDate()} ${MONTHS_SHORT[a.getMonth()]} ${a.getFullYear()}`;
  }
  return `${shortDay(start)} – ${shortDay(end)}`;
}

export function frTime(value) {
  return value ? value.replace(':', 'h') : '';
}

export function agoLabel(isoTimestamp) {
  const then = new Date(isoTimestamp).getTime();
  const minutes = Math.round((Date.now() - then) / 60000);
  if (minutes < 1) return "À l'instant";
  if (minutes < 60) return `Il y a ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `Il y a ${hours} h`;
  const days = Math.round(hours / 24);
  if (days === 1) return 'Hier';
  return `Il y a ${days} j`;
}

export function dayLabel(isoTimestamp) {
  return shortDay(isoDate(new Date(isoTimestamp)));
}
