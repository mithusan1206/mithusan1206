import { db } from './db.js';

export const POST_COLORS = ['sage', 'lime', 'yellow', 'pink', 'purple', 'blue', 'orange', 'coral'];
const RESERVED = new Set(['R.H.', 'CA', 'RTT', 'J.F.', 'ABS']);
const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;

function fail(message, status) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function requireCadre(user) {
  if (user.role !== 'cadre') fail('Réservé au cadre de santé', 403);
}

function serialize(row) {
  const count = db.prepare(
    `SELECT COUNT(*) AS count FROM habilitations
     WHERE post_id = ? AND status IN ('Habilité', 'Expire bientôt')`,
  ).get(row.id);
  return {
    id: row.id,
    name: row.name,
    code: row.code,
    description: row.description,
    startTime: row.start_time,
    endTime: row.end_time,
    color: row.color,
    active: row.active === 1,
    habilitatedCount: count.count,
  };
}

function readPost(id) {
  const row = db.prepare(`SELECT * FROM posts WHERE id = ?`).get(id);
  if (!row) fail('Poste introuvable', 404);
  return row;
}

function parsePost(body, current) {
  const name = String(body?.name ?? '').trim();
  const code = String(body?.code ?? '').trim();
  const description = String(body?.description ?? '').trim();
  const startTime = String(body?.startTime ?? '').trim().slice(0, 5);
  const endTime = String(body?.endTime ?? '').trim().slice(0, 5);
  const color = String(body?.color ?? 'sage');
  const active = body?.active === false ? 0 : 1;

  if (!name || name.length > 40) fail('Indiquez le nom du poste', 400);
  if (!code || code.length > 16) fail('Indiquez le code du poste', 400);
  if (RESERVED.has(code.toUpperCase()) || RESERVED.has(code)) fail('Ce code est réservé', 400);
  if (description.length > 200) fail('La description est trop longue', 400);
  if (!TIME.test(startTime) || !TIME.test(endTime)) fail('Indiquez des heures au format HH:MM', 400);
  if (startTime >= endTime) fail('L’heure de fin doit être après l’heure de début', 400);
  if (!POST_COLORS.includes(color)) fail('Couleur invalide', 400);

  const duplicate = db.prepare(`SELECT id FROM posts WHERE code = ? AND id != ?`).get(code, current?.id ?? 0);
  if (duplicate) fail('Ce code est déjà utilisé', 409);

  return { name, code, description, startTime, endTime, color, active };
}

export function listPosts(user) {
  const rows = user.role === 'cadre'
    ? db.prepare(`SELECT * FROM posts ORDER BY active DESC, name`).all()
    : db.prepare(`SELECT * FROM posts WHERE active = 1 ORDER BY name`).all();
  return rows.map(serialize);
}

export function activePosts() {
  return db.prepare(`SELECT * FROM posts WHERE active = 1 ORDER BY name`).all();
}

export function getPost(user, id) {
  requireCadre(user);
  const post = readPost(id);
  const granted = new Set(
    db.prepare(
      `SELECT user_id FROM habilitations
       WHERE post_id = ? AND status IN ('Habilité', 'Expire bientôt')`,
    ).all(id).map((row) => row.user_id),
  );
  const agents = db.prepare(
    `SELECT id, name FROM users WHERE role = 'technicien' AND active = 1 ORDER BY name`,
  ).all().map((agent) => ({
    id: agent.id,
    name: agent.name,
    enabled: granted.has(agent.id),
  }));
  return { ...serialize(post), agents };
}

export function createPost(user, body) {
  requireCadre(user);
  const fields = parsePost(body);
  const result = db.prepare(
    `INSERT INTO posts (name, code, description, start_time, end_time, color, active, required_agents)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1)`,
  ).run(fields.name, fields.code, fields.description, fields.startTime, fields.endTime, fields.color, fields.active);
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
    user.id,
    `Poste créé — ${fields.code}`,
    new Date().toISOString(),
  );
  return serialize(readPost(Number(result.lastInsertRowid)));
}

export function updatePost(user, id, body) {
  requireCadre(user);
  const current = readPost(id);
  const fields = parsePost(body, current);
  db.exec('BEGIN');
  try {
    if (fields.code !== current.code) {
      db.prepare(`UPDATE assignments SET code = ? WHERE code = ?`).run(fields.code, current.code);
    }
    db.prepare(
      `UPDATE posts
       SET name = ?, code = ?, description = ?, start_time = ?, end_time = ?, color = ?, active = ?
       WHERE id = ?`,
    ).run(fields.name, fields.code, fields.description, fields.startTime, fields.endTime, fields.color, fields.active, id);
    db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
      user.id,
      `Poste modifié — ${fields.code}`,
      new Date().toISOString(),
    );
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
  return serialize(readPost(id));
}

export function deletePost(user, id) {
  requireCadre(user);
  const current = readPost(id);
  db.exec('BEGIN');
  try {
    db.prepare(`UPDATE assignments SET code = 'R.H.' WHERE code = ?`).run(current.code);
    db.prepare(`DELETE FROM posts WHERE id = ?`).run(id);
    db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
      user.id,
      `Poste supprimé — ${current.code}`,
      new Date().toISOString(),
    );
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
  return { ok: true };
}

export function setHabilitation(user, body) {
  requireCadre(user);
  const post = readPost(Number(body?.postId));
  const agent = db.prepare(`SELECT * FROM users WHERE id = ?`).get(Number(body?.userId));
  if (!agent || agent.role !== 'technicien') fail('Technicien introuvable', 404);
  const enabled = body?.enabled === true;
  if (enabled) {
    db.prepare(
      `INSERT INTO habilitations (user_id, post_id, status, valid_until)
       VALUES (?, ?, 'Habilité', NULL)
       ON CONFLICT(user_id, post_id) DO UPDATE SET status = 'Habilité'`,
    ).run(agent.id, post.id);
  } else {
    db.prepare(`DELETE FROM habilitations WHERE user_id = ? AND post_id = ?`).run(agent.id, post.id);
  }
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
    user.id,
    enabled ? `Habilitation ${post.code} attribuée — ${agent.name}` : `Habilitation ${post.code} retirée — ${agent.name}`,
    new Date().toISOString(),
  );
  db.prepare(`INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`).run(
    agent.id,
    enabled ? `Habilitation ${post.code} attribuée` : `Habilitation ${post.code} retirée`,
    new Date().toISOString(),
  );
  return { postId: post.id, userId: agent.id, enabled };
}
