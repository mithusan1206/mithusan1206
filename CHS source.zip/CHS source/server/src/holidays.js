function easterDate(year) {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31) - 1;
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month, day);
}

function key(date) {
  return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
}

const cache = new Map();

function holidaySet(year) {
  if (cache.has(year)) return cache.get(year);
  const easter = easterDate(year);
  const add = (date, days) => {
    const next = new Date(date);
    next.setDate(next.getDate() + days);
    return next;
  };
  const set = new Set([
    key(new Date(year, 0, 1)),
    key(add(easter, 1)),
    key(new Date(year, 4, 1)),
    key(new Date(year, 4, 8)),
    key(add(easter, 39)),
    key(add(easter, 50)),
    key(new Date(year, 6, 14)),
    key(new Date(year, 7, 15)),
    key(new Date(year, 10, 1)),
    key(new Date(year, 10, 11)),
    key(new Date(year, 11, 25)),
  ]);
  cache.set(year, set);
  return set;
}

export function isHoliday(date) {
  return holidaySet(date.getFullYear()).has(key(date));
}

export function isWeekend(date) {
  const day = date.getDay();
  return day === 0 || day === 6;
}

export function nextServiceDate(from) {
  let cursor = new Date(from);
  for (let i = 0; i < 14; i += 1) {
    if (!isWeekend(cursor) && !isHoliday(cursor)) return cursor;
    cursor.setDate(cursor.getDate() + 1);
  }
  return from;
}
