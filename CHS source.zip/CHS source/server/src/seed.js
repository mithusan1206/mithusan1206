import { scryptSync, randomBytes } from 'node:crypto';
import { backfillPersonnel, db } from './db.js';
import { isoDate } from './dates.js';
import { generateRange } from './planning.js';

const LAB = 'Laboratoire de microbiologie médicale';

function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 32).toString('hex');
  return `${salt}:${hash}`;
}

function hoursAgo(hours) {
  return new Date(Date.now() - hours * 3600 * 1000).toISOString();
}

const TECHS = [
  { email: 'sophie.moreau@lab.chs', name: 'Sophie Moreau', job: 'Technicienne', contract: '100%', ca: [12, 25], rtt: [4, 10] },
  { email: 'lucas.bernard@lab.chs', name: 'Lucas Bernard', job: 'Technicien', contract: '100%', ca: [15, 25], rtt: [7, 10] },
  { email: 'emma.petit@lab.chs', name: 'Emma Petit', job: 'Technicienne', contract: '100%', ca: [20, 25], rtt: [8, 10] },
  { email: 'paul.durand@lab.chs', name: 'Paul Durand', job: 'Technicien', contract: '100%', ca: [9, 25], rtt: [3, 10] },
  { email: 'lea.rousseau@lab.chs', name: 'Léa Rousseau', job: 'Technicienne', contract: '100%', ca: [11, 25], rtt: [5, 10] },
  { email: 'thomas.girard@lab.chs', name: 'Thomas Girard', job: 'Technicien', contract: '100%', ca: [18, 25], rtt: [6, 10] },
  { email: 'clara.leroy@lab.chs', name: 'Clara Leroy', job: 'Technicienne', contract: '80%', ca: [14, 25], rtt: [4, 10] },
  { email: 'maxime.fontaine@lab.chs', name: 'Maxime Fontaine', job: 'Technicien', contract: '100%', ca: [16, 25], rtt: [9, 10] },
];

export function seedIfEmpty() {
  const existing = db.prepare(`SELECT COUNT(*) AS count FROM users`).get();
  if (existing.count > 0) return;

  const insertUser = db.prepare(
    `INSERT INTO users (email, password_hash, name, role, job_title, contract, lab_name)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  );
  const insertLeave = db.prepare(
    `INSERT INTO leave_balances (user_id, ca_remaining, ca_total, rtt_remaining, rtt_total)
     VALUES (?, ?, ?, ?, ?)`,
  );
  const insertRequest = db.prepare(
    `INSERT INTO requests (user_id, type, start_date, end_date, reason, status, created_at, resolved_at, resolved_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  const insertActivity = db.prepare(
    `INSERT INTO activity (user_id, action, created_at) VALUES (?, ?, ?)`,
  );

  const password = hashPassword('demo');

  db.exec('BEGIN');
  try {
    const martin = insertUser.run(
      'martin@lab.chs', password, 'Dr. Martin', 'cadre', 'Cadre de santé', '100%', LAB,
    );
    insertLeave.run(Number(martin.lastInsertRowid), 18, 25, 6, 10);

    const ids = {};
    for (const tech of TECHS) {
      const row = insertUser.run(tech.email, password, tech.name, 'technicien', tech.job, tech.contract, LAB);
      const id = Number(row.lastInsertRowid);
      ids[tech.email] = id;
      insertLeave.run(id, tech.ca[0], tech.ca[1], tech.rtt[0], tech.rtt[1]);
    }

    const cadreId = Number(martin.lastInsertRowid);
    const sophie = ids['sophie.moreau@lab.chs'];
    const now = new Date().toISOString();

    insertRequest.run(ids['thomas.girard@lab.chs'], 'CA', '2026-10-14', '2026-10-16', 'Vacances familiales', 'En attente', hoursAgo(2), null, null);
    insertRequest.run(ids['clara.leroy@lab.chs'], 'RTT', '2026-10-21', '2026-10-21', 'Récupération heures sup.', 'En attente', hoursAgo(3), null, null);
    insertRequest.run(ids['lea.rousseau@lab.chs'], 'Absence', '2026-10-13', '2026-10-13', 'Maladie – justificatif joint', 'En attente', hoursAgo(26), null, null);
    insertRequest.run(ids['maxime.fontaine@lab.chs'], 'H. sup.', '2026-10-12', '2026-10-12', 'Urgence laboratoire – 3h', 'Validée', hoursAgo(48), hoursAgo(47), cadreId);
    insertRequest.run(sophie, 'CA', '2026-11-01', '2026-11-03', 'Déplacement personnel', 'Validée', hoursAgo(72), hoursAgo(70), cadreId);
    insertRequest.run(ids['lucas.bernard@lab.chs'], 'Échange', '2026-10-17', '2026-10-17', 'Échange de poste avec P. Durand', 'En attente', hoursAgo(5), null, null);
    insertRequest.run(ids['emma.petit@lab.chs'], 'Retard', '2026-10-11', '2026-10-11', 'Problème transport – 25 min', 'Validée', hoursAgo(96), hoursAgo(90), cadreId);
    insertRequest.run(ids['paul.durand@lab.chs'], 'RTT', '2026-10-28', '2026-10-28', 'RTT annuel', 'Refusée', hoursAgo(30), hoursAgo(20), cadreId);

    insertActivity.run(cadreId, 'Planning initial généré', now);
    insertActivity.run(cadreId, 'CA validé — Sophie Moreau', hoursAgo(70));
    insertActivity.run(sophie, 'CA validé — 1–3 nov. 2026', hoursAgo(70));
    insertActivity.run(ids['maxime.fontaine@lab.chs'], 'Heures sup. validées (3h)', hoursAgo(47));
    insertActivity.run(ids['emma.petit@lab.chs'], 'Retard validé', hoursAgo(90));
    insertActivity.run(ids['paul.durand@lab.chs'], 'RTT refusé', hoursAgo(20));

    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }

  backfillPersonnel();
  const start = new Date();
  const from = isoDate(new Date(start.getFullYear(), start.getMonth(), 1));
  const to = isoDate(new Date(start.getFullYear(), start.getMonth() + 3, 0));
  generateRange(from, to, 100);
}
