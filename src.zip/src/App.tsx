import { useEffect, useState } from 'react';
import { api, clearSession, type Viewer } from './api';
import BottomNav from './components/BottomNav';
import CadreAccountScreen from './screens/CadreAccount';
import Dashboard from './screens/Dashboard';
import Login from './screens/Login';
import Planning from './screens/Planning';
import Profile from './screens/Profile';
import Requests from './screens/Requests';
import Team from './screens/Team';

type Tab = 'dashboard' | 'planning' | 'team' | 'requests' | 'profile';

export default function App() {
  const [user, setUser] = useState<Viewer | null>(null);
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<Tab>('dashboard');
  const [profileId, setProfileId] = useState<number | null>(null);
  const [accountOpen, setAccountOpen] = useState(false);

  useEffect(() => {
    api.me()
      .then((result) => setUser(result.user))
      .catch(() => setUser(null))
      .finally(() => setReady(true));
    const onUnauthorized = () => setUser(null);
    window.addEventListener('lab-unauthorized', onUnauthorized);
    return () => window.removeEventListener('lab-unauthorized', onUnauthorized);
  }, []);

  function selectTab(next: Tab) {
    setTab(next);
    if (next === 'profile') setProfileId(null);
  }

  async function logout() {
    try { await api.logout(); } catch { clearSession(); }
    setUser(null);
    setTab('dashboard');
    setProfileId(null);
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', justifyContent: 'center' }}>
      <div style={{
        width: '100%',
        maxWidth: 430,
        height: '100vh',
        background: 'var(--bg)',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        overflow: 'hidden',
        paddingTop: 'env(safe-area-inset-top)',
      }}>
        {!ready ? (
          <p style={{ padding: 28, color: 'var(--text-secondary)' }}>Chargement…</p>
        ) : !user ? (
          <div style={{ flex: 1, overflowY: 'auto' }} className="scrollbar-hide">
            <Login onSuccess={setUser} />
          </div>
        ) : (
          <>
            <div style={{ flex: 1, minHeight: 0, overflowY: tab === 'planning' ? 'hidden' : 'auto' }} className="scrollbar-hide">
              {tab === 'dashboard' && (
                <Dashboard
                  onOpenPlanning={() => selectTab('planning')}
                  onOpenAccount={user.role === 'cadre' ? () => setAccountOpen(true) : undefined}
                />
              )}
              {tab === 'planning' && <Planning isCadre={user.role === 'cadre'} />}
              {tab === 'team' && (
                <Team
                  isCadre={user.role === 'cadre'}
                  viewerId={user.id}
                  onOpenProfile={(id) => { setProfileId(id); setTab('profile'); }}
                />
              )}
              {tab === 'requests' && <Requests viewerId={user.id} />}
              {tab === 'profile' && (
                <Profile userId={profileId} onLogout={logout} onBack={() => setProfileId(null)} />
              )}
            </div>
            <BottomNav active={tab} onChange={selectTab} />
            {accountOpen && <CadreAccountScreen onClose={() => setAccountOpen(false)} />}
          </>
        )}
      </div>
    </div>
  );
}
