export type PostColor = {
  id: string;
  label: string;
  bg: string;
  text: string;
  border: string;
};

export const POST_COLORS: PostColor[] = [
  { id: 'sage', label: 'Sauge', bg: '#C8E6C9', text: '#1B5E20', border: '#A5D6A7' },
  { id: 'lime', label: 'Lime', bg: '#DCEDC8', text: '#33691E', border: '#C5E1A5' },
  { id: 'yellow', label: 'Jaune', bg: '#FFF9C4', text: '#F57F17', border: '#FFF176' },
  { id: 'pink', label: 'Rose', bg: '#F8BBD0', text: '#880E4F', border: '#F48FB1' },
  { id: 'purple', label: 'Violet', bg: '#E1BEE7', text: '#4A148C', border: '#CE93D8' },
  { id: 'blue', label: 'Bleu', bg: '#BBDEFB', text: '#0D47A1', border: '#90CAF9' },
  { id: 'orange', label: 'Orange', bg: '#FFE0B2', text: '#E65100', border: '#FFCC80' },
  { id: 'coral', label: 'Corail', bg: '#FFCCBC', text: '#BF360C', border: '#FFAB91' },
];

export function colorById(id: string) {
  return POST_COLORS.find((color) => color.id === id) ?? POST_COLORS[0];
}
