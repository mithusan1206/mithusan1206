type Tab = 'dashboard' | 'planning' | 'team' | 'requests' | 'profile';

interface BottomNavProps {
  active: Tab;
  onChange: (tab: Tab) => void;
}

const tabs: { id: Tab; label: string; icon: (active: boolean) => React.ReactNode }[] = [
  {
    id: 'dashboard',
    label: 'Accueil',
    icon: (a) => (
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24">
        <path d="M3 12L12 4l9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1v-9z"
          fill={a ? '#171918' : '#737873'} />
      </svg>
    ),
  },
  {
    id: 'planning',
    label: 'Planning',
    icon: (a) => (
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24">
        <rect x="3" y="4" width="18" height="18" rx="3" stroke={a ? '#171918' : '#737873'} strokeWidth="2" fill="none"/>
        <path d="M3 9h18M8 2v4M16 2v4" stroke={a ? '#171918' : '#737873'} strokeWidth="2" strokeLinecap="round"/>
        <rect x="7" y="12" width="3" height="3" rx="1" fill={a ? '#171918' : '#737873'}/>
        <rect x="14" y="12" width="3" height="3" rx="1" fill={a ? '#171918' : '#737873'}/>
      </svg>
    ),
  },
  {
    id: 'team',
    label: 'Équipe',
    icon: (a) => (
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24">
        <circle cx="9" cy="7" r="3" stroke={a ? '#171918' : '#737873'} strokeWidth="2"/>
        <path d="M3 20c0-4 3-6 6-6s6 2 6 6" stroke={a ? '#171918' : '#737873'} strokeWidth="2" strokeLinecap="round"/>
        <circle cx="17" cy="8" r="2.5" stroke={a ? '#171918' : '#737873'} strokeWidth="1.8"/>
        <path d="M21 20c0-3-2-4.5-4-4.5" stroke={a ? '#171918' : '#737873'} strokeWidth="1.8" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    id: 'requests',
    label: 'Demandes',
    icon: (a) => (
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24">
        <rect x="3" y="5" width="18" height="14" rx="3" stroke={a ? '#171918' : '#737873'} strokeWidth="2" fill="none"/>
        <path d="M3 9l9 6 9-6" stroke={a ? '#171918' : '#737873'} strokeWidth="2" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    id: 'profile',
    label: 'Profil',
    icon: (a) => (
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24">
        <circle cx="12" cy="8" r="4" stroke={a ? '#171918' : '#737873'} strokeWidth="2"/>
        <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke={a ? '#171918' : '#737873'} strokeWidth="2" strokeLinecap="round"/>
      </svg>
    ),
  },
];

export default function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <div style={{
      position: 'fixed',
      bottom: 'calc(12px + env(safe-area-inset-bottom))',
      left: '50%',
      transform: 'translateX(-50%)',
      width: 'calc(100% - 24px)',
      maxWidth: 406,
      background: '#171918',
      borderRadius: 28,
      height: 68,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      padding: '0 8px',
      zIndex: 100,
      boxShadow: '0 8px 32px rgba(0,0,0,0.25)',
    }}>
      {tabs.map(tab => {
        const isActive = tab.id === active;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              background: isActive ? '#B8E986' : 'transparent',
              border: 'none',
              borderRadius: 20,
              padding: isActive ? '8px 14px' : '8px 10px',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              flexShrink: 0,
            }}
          >
            {tab.icon(isActive)}
            {isActive && (
              <span style={{
                color: '#171918',
                fontSize: 12,
                fontWeight: 700,
                whiteSpace: 'nowrap',
              }}>
                {tab.label}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
