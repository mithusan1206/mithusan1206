interface AvatarProps {
  name: string;
  size?: 32 | 40 | 48;
  color?: string;
}

const colors = ['#A8BFA8','#B8E986','#F4B183','#F3C6CE','#8DBF91','#E8AA72'];

function getColor(name: string) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

function initials(name: string) {
  return name.split(' ').map(n => n[0]).slice(0,2).join('').toUpperCase();
}

export default function Avatar({ name, size = 40 }: AvatarProps) {
  const bg = getColor(name);
  return (
    <div style={{
      width: size,
      height: size,
      borderRadius: '50%',
      background: bg,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
      fontSize: size === 32 ? 11 : size === 40 ? 13 : 16,
      fontWeight: 700,
      color: '#202321',
      letterSpacing: '0.02em',
    }}>
      {initials(name)}
    </div>
  );
}
