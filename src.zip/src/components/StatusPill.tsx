interface StatusPillProps {
  label: string;
  variant?: 'success' | 'warning' | 'danger' | 'info' | 'neutral';
}

const variants: Record<string, { bg: string; color: string }> = {
  success: { bg: '#E6F5E7', color: '#3A7D44' },
  warning: { bg: '#FFF0E0', color: '#A05C00' },
  danger:  { bg: '#FDEAEA', color: '#A03030' },
  info:    { bg: '#E8F0FE', color: '#1A56DB' },
  neutral: { bg: '#ECECEC', color: '#555' },
};

export default function StatusPill({ label, variant = 'neutral' }: StatusPillProps) {
  const v = variants[variant];
  return (
    <span style={{
      background: v.bg,
      color: v.color,
      borderRadius: 50,
      fontSize: 11,
      fontWeight: 600,
      padding: '3px 10px',
      whiteSpace: 'nowrap',
    }}>
      {label}
    </span>
  );
}
