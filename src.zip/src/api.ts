const TOKEN_KEY = 'lab_token';
const SERVER_KEY = 'lab_server';

export type Role = 'cadre' | 'technicien';

export type CadreAccount = {
  firstName: string;
  lastName: string;
  name: string;
  roleLabel: string;
  email: string;
  loginId: string;
  labName: string;
  permissions: string[];
};

export type Viewer = {
  id: number;
  name: string;
  role: Role;
  jobTitle: string;
  contract: string;
  labName: string;
};

export function getServer() {
  return localStorage.getItem(SERVER_KEY) ?? '';
}

export function setServer(url: string) {
  const next = url.trim().replace(/\/$/, '');
  if (next) localStorage.setItem(SERVER_KEY, next);
  else localStorage.removeItem(SERVER_KEY);
}

export function clearSession() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (!headers.has('Content-Type') && options.body) headers.set('Content-Type', 'application/json');
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) headers.set('Authorization', `Bearer ${token}`);

  let response: Response;
  try {
    response = await fetch(`${getServer()}${path}`, { ...options, headers });
  } catch {
    throw new Error('Serveur injoignable. Sur téléphone, indiquez l’adresse du PC.');
  }
  if (response.status === 401) {
    clearSession();
    window.dispatchEvent(new Event('lab-unauthorized'));
  }
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || 'Le serveur est injoignable');
  }
  return response.json() as Promise<T>;
}

export const api = {
  async login(email: string, password: string) {
    const result = await request<{ token: string; user: Viewer }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    localStorage.setItem(TOKEN_KEY, result.token);
    return result.user;
  },
  me() {
    return request<{ user: Viewer }>('/api/me');
  },
  account() {
    return request<CadreAccount>('/api/account');
  },
  changeLoginId(loginId: string) {
    return request<CadreAccount>('/api/account/login', {
      method: 'PATCH',
      body: JSON.stringify({ loginId }),
    });
  },
  changePassword(currentPassword: string, newPassword: string) {
    return request<{ ok: boolean }>('/api/account/password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    });
  },
  logout() {
    return request<{ ok: boolean }>('/api/auth/session', { method: 'DELETE' }).finally(clearSession);
  },
  dashboard() {
    return request<DashboardData>('/api/dashboard');
  },
  planning(from: string, to: string) {
    return request<PlanningData>(`/api/planning?from=${from}&to=${to}`);
  },
  generatePlanning(from: string, to: string) {
    return request<PlanningData>('/api/planning/generate', {
      method: 'POST',
      body: JSON.stringify({ from, to }),
    });
  },
  team(q: string, filter: string) {
    const params = new URLSearchParams({ q, filter });
    return request<TeamData>(`/api/team?${params}`);
  },
  requests(category: string) {
    return request<RequestsData>(`/api/requests?category=${encodeURIComponent(category)}`);
  },
  decide(id: number, action: 'approve' | 'reject') {
    return request(`/api/requests/${id}/decision`, {
      method: 'POST',
      body: JSON.stringify({ action }),
    });
  },
  exchangeOptions(date: string) {
    return request<ExchangeOptions>(`/api/exchanges/options?date=${date}`);
  },
  createExchange(body: { partnerId: number; startDate: string; endDate: string; reason: string }) {
    return request<{ id: number }>('/api/exchanges', { method: 'POST', body: JSON.stringify(body) });
  },
  updateExchange(id: number, body: { startDate: string; endDate: string; reason: string }) {
    return request<{ id: number }>(`/api/exchanges/${id}`, { method: 'PATCH', body: JSON.stringify(body) });
  },
  deleteExchange(id: number) {
    return request<{ ok: boolean }>(`/api/exchanges/${id}`, { method: 'DELETE' });
  },
  replyExchange(id: number, action: 'accept' | 'refuse') {
    return request<{ ok: boolean }>(`/api/exchanges/${id}/reply`, {
      method: 'POST',
      body: JSON.stringify({ action }),
    });
  },
  profile(userId?: number) {
    return request<ProfileData>(userId ? `/api/team/${userId}` : '/api/profile');
  },
  posts() {
    return request<{ posts: LabPost[] }>('/api/posts');
  },
  post(id: number) {
    return request<LabPostDetail>(`/api/posts/${id}`);
  },
  createPost(body: PostInput) {
    return request<LabPost>('/api/posts', { method: 'POST', body: JSON.stringify(body) });
  },
  updatePost(id: number, body: PostInput) {
    return request<LabPost>(`/api/posts/${id}`, { method: 'PATCH', body: JSON.stringify(body) });
  },
  deletePost(id: number) {
    return request<{ ok: boolean }>(`/api/posts/${id}`, { method: 'DELETE' });
  },
  setHabilitation(userId: number, postId: number, enabled: boolean) {
    return request('/api/habilitations', {
      method: 'PUT',
      body: JSON.stringify({ userId, postId, enabled }),
    });
  },
  personnelTypes() {
    return request<{ types: PersonnelType[] }>('/api/personnel-types');
  },
  createPersonnelType(name: string) {
    return request<PersonnelType>('/api/personnel-types', { method: 'POST', body: JSON.stringify({ name }) });
  },
  updatePersonnelType(id: number, name: string) {
    return request<PersonnelType>(`/api/personnel-types/${id}`, { method: 'PATCH', body: JSON.stringify({ name }) });
  },
  deletePersonnelType(id: number) {
    return request<{ ok: boolean }>(`/api/personnel-types/${id}`, { method: 'DELETE' });
  },
  personnel() {
    return request<{ personnel: PersonnelMember[] }>('/api/personnel');
  },
  person(id: number) {
    return request<PersonnelDetail>(`/api/personnel/${id}`);
  },
  createPersonnel(body: PersonnelInput) {
    return request<PersonnelDetail>('/api/personnel', { method: 'POST', body: JSON.stringify(body) });
  },
  updatePersonnel(id: number, body: PersonnelInput) {
    return request<PersonnelDetail>(`/api/personnel/${id}`, { method: 'PATCH', body: JSON.stringify(body) });
  },
  deletePersonnel(id: number) {
    return request<{ ok: boolean }>(`/api/personnel/${id}`, { method: 'DELETE' });
  },
};

export type DashboardData = {
  greeting: string;
  todayLabel: string;
  subtitle: string;
  coverageTitle: string;
  canValidate: boolean;
  kpis: { label: string; value: string; sub: string; tone: 'sage' | 'neon' | 'pink' | 'orange' }[];
  viewerName: string;
  planning: { userId: number; name: string; post: string; time: string; habilite: boolean }[];
  coverage: { name: string; coverage: number }[];
  pendingBadge: number;
  requests: { id: number; name: string; type: string; dates: string; reason: string; status: string; waitingFor?: string }[];
  alerts: { id: string; level: string; message: string; timeLabel: string }[];
};

export type LabPost = {
  id: number;
  name: string;
  code: string;
  description: string;
  startTime: string;
  endTime: string;
  color: string;
  active: boolean;
  habilitatedCount: number;
};

export type PostInput = {
  name: string;
  code: string;
  description: string;
  startTime: string;
  endTime: string;
  color: string;
  active: boolean;
};

export type LabPostDetail = LabPost & {
  agents: { id: number; name: string; enabled: boolean }[];
};

export type PersonnelType = { id: number; name: string; used: number };

export type PersonnelMember = {
  id: number;
  firstName: string;
  lastName: string;
  name: string;
  typeId: number;
  typeName: string;
  quota: number;
  arrivalDate: string;
  active: boolean;
  planningNotes: string;
  loginId: string;
};

export type PersonnelInput = {
  firstName: string;
  lastName: string;
  typeId: number;
  quota: number;
  arrivalDate: string;
  active: boolean;
  planningNotes: string;
  loginId: string;
  password: string;
};

export type PersonnelDetail = PersonnelMember & {
  posts: { id: number; code: string; name: string; active: boolean; enabled: boolean }[];
};

export type PlanningData = {
  canGenerate: boolean;
  posts: LabPost[];
  agents: { id: number; name: string; role: string }[];
  cells: { userId: number; date: string; code: string }[];
  hours: Record<string, { start: string; end: string }>;
};

export type TeamData = {
  counts: { total: number; present: number; absent: number; off: number };
  members: {
    id: number;
    name: string;
    role: string;
    post: string;
    status: 'present' | 'absent' | 'leave' | 'off';
    statusLabel: string;
    habilitations: number;
    expiring: boolean;
  }[];
};

export type ExchangeOptions = {
  ownCode: string;
  canAsk: boolean;
  partners: { id: number; name: string; code: string; hours: string }[];
};

export type RequestsData = {
  pending: number;
  canRequest: boolean;
  items: {
    id: number;
    name: string;
    type: string;
    dates: string;
    reason: string;
    status: string;
    createdLabel: string;
    canValidate: boolean;
    canApproveExchange: boolean;
    canAnswerExchange: boolean;
    canManageExchange: boolean;
    exchange: {
      fromName: string;
      toName: string;
      dateLabel: string;
      focusLabel: string;
      fromCode: string;
      toCode: string;
      days: { dateLabel: string; fromCode: string; toCode: string }[];
      partnerId: number;
      startDate: string;
      endDate: string;
      colleagueAccepted: boolean;
      waitingColleague: boolean;
    } | null;
  }[];
};

export type ProfileData = {
  viewingSelf: boolean;
  canAssign: boolean;
  name: string;
  jobTitle: string;
  labName: string;
  statusLabel: string;
  leave: { caRemaining: number; caTotal: number; rttRemaining: number; rttTotal: number };
  habilitations: { post: string; status: string; validLabel: string }[];
  catalog: { id: number; code: string; name: string; color: string; active: boolean; enabled: boolean; status: string }[];
  calendar: { monthLabel: string; offset: number; days: number; marked: number[]; today: number };
  activity: { action: string; dateLabel: string }[];
};
