import { FormEvent, useState } from 'react';
import { api, getServer, setServer, type Viewer } from '../api';

const DEMOS = [
  { label: 'Cadre de santé', email: 'martin@lab.chs' },
  { label: 'Technicienne', email: 'sophie.moreau@lab.chs' },
];

export default function Login({ onSuccess }: { onSuccess: (user: Viewer) => void }) {
  const [email, setEmail] = useState(DEMOS[0].email);
  const [password, setPassword] = useState('demo');
  const [server, setServerValue] = useState(getServer());
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError('');
    setServer(server);
    try {
      onSuccess(await api.login(email, password));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Connexion impossible');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ minHeight: '100%', padding: '48px 24px 32px', display: 'flex', flexDirection: 'column' }}>
      <div style={{
        width: 56, height: 56, borderRadius: 18, background: '#171918', color: '#B8E986',
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 18,
      }}>LAB</div>
      <h1 style={{ margin: '20px 0 6px', fontSize: 28, fontWeight: 700 }}>Connexion</h1>
      <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.45 }}>
        Planning, équipe et demandes du laboratoire de microbiologie.
      </p>

      <form onSubmit={submit} style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 12 }}>
        <Field label="Identifiant" value={email} onChange={setEmail} type="text" />
        <Field label="Mot de passe" value={password} onChange={setPassword} type="password" />
        <Field
          label="Serveur (iPhone / Android)"
          value={server}
          onChange={setServerValue}
          type="url"
          placeholder="http://192.168.1.20:3001"
        />
        <p style={{ margin: 0, fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.4 }}>
          Sur ordinateur, laissez ce champ vide. Sur téléphone, indiquez l’adresse affichée au démarrage du serveur.
        </p>
        {error && <p style={{ margin: 0, color: '#A03030', fontSize: 13 }}>{error}</p>}
        <button type="submit" disabled={busy} style={{
          marginTop: 8, padding: '14px', borderRadius: 16, border: 'none',
          background: '#171918', color: '#B8E986', fontWeight: 700, fontSize: 15, cursor: 'pointer',
        }}>{busy ? 'Connexion…' : 'Se connecter'}</button>
      </form>

      <div style={{ marginTop: 28 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)', marginBottom: 8 }}>
          Comptes de démonstration · mot de passe demo
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {DEMOS.map((demo) => (
            <button key={demo.email} type="button" onClick={() => { setEmail(demo.email); setPassword('demo'); }} style={{
              textAlign: 'left', background: 'white', border: '1.5px solid var(--border)', borderRadius: 14,
              padding: '12px 14px', cursor: 'pointer',
            }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>{demo.label}</div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{demo.email}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type, placeholder }: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type: string;
  placeholder?: string;
}) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>{label}</span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        style={{
          border: '1.5px solid var(--border)', background: 'white', borderRadius: 14,
          padding: '12px 14px', fontSize: 15, color: 'var(--text-primary)', outline: 'none',
        }}
      />
    </label>
  );
}
