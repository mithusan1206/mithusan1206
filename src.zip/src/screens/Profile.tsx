import { useEffect, useState } from 'react';
import { api, type ProfileData } from '../api';
import StatusPill from '../components/StatusPill';

function initials(name: string) {
  return name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase();
}

function ProgressRing({ value, max, color, label, sublabel }: { value: number; max: number; color: string; label: string; sublabel: string }) {
  const radius = 36;
  const circ = 2 * Math.PI * radius;
  const filled = max === 0 ? 0 : (value / max) * circ;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <svg width={88} height={88} viewBox="0 0 88 88">
        <circle cx={44} cy={44} r={radius} fill="none" stroke="#F0F0F0" strokeWidth={8} />
        <circle cx={44} cy={44} r={radius} fill="none" stroke={color} strokeWidth={8} strokeDasharray={`${filled} ${circ}`} strokeLinecap="round" transform="rotate(-90 44 44)" />
        <text x={44} y={44} textAnchor="middle" dominantBaseline="central" fontSize={16} fontWeight={700} fill="#202321">{value}</text>
      </svg>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>{label}</div>
        <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{sublabel}</div>
      </div>
    </div>
  );
}

export default function Profile({ userId, onLogout, onBack }: { userId: number | null; onLogout: () => void; onBack: () => void }) {
  const [data, setData] = useState<ProfileData | null>(null);
  const [error, setError] = useState('');

  function reload(id = userId) {
    setData(null);
    api.profile(id ?? undefined)
      .then((result) => { setData(result); setError(''); })
      .catch((err) => setError(err instanceof Error ? err.message : 'Chargement impossible'));
  }

  useEffect(() => { reload(); }, [userId]);

  async function assign(postId: number, enabled: boolean) {
    if (!userId) return;
    try {
      await api.setHabilitation(userId, postId, enabled);
      const result = await api.profile(userId);
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Habilitation impossible');
    }
  }

  if (!data) return <p style={{ padding: 28, color: 'var(--text-secondary)' }}>{error || 'Chargement…'}</p>;

  return (
    <div style={{ paddingBottom: 100 }}>
      {!data.viewingSelf && (
        <button onClick={onBack} style={{ margin: '16px 20px 0', background: 'none', border: 'none', color: 'var(--text-secondary)', fontWeight: 600, cursor: 'pointer', padding: 0 }}>
          Retour à l’équipe
        </button>
      )}
      <div style={{ background: '#171918', padding: '36px 24px 28px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ width: 80, height: 80, borderRadius: '50%', background: '#B8E986', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 700, color: '#171918' }}>
          {initials(data.name)}
        </div>
        <h1 style={{ margin: '12px 0 4px', fontSize: 22, fontWeight: 700, color: 'white' }}>{data.name}</h1>
        <p style={{ margin: 0, fontSize: 14, color: '#A8BFA8' }}>{data.jobTitle}</p>
        <p style={{ margin: '4px 0 0', fontSize: 12, color: '#737873' }}>{data.labName}</p>
        <div style={{ marginTop: 14 }}><StatusPill label={data.statusLabel} variant="success" /></div>
      </div>

      <div style={{ padding: '24px 20px 8px' }}>
        <h2 style={{ margin: '0 0 16px', fontSize: 17, fontWeight: 700 }}>Solde de congés</h2>
        <div style={{ background: 'white', borderRadius: 20, padding: 20, boxShadow: '0 2px 10px rgba(0,0,0,0.06)', display: 'flex', justifyContent: 'space-around' }}>
          <ProgressRing value={data.leave.caRemaining} max={data.leave.caTotal} color="#B8E986" label="CA restants" sublabel={`sur ${data.leave.caTotal} jours`} />
          <div style={{ width: 1, background: 'var(--border)' }} />
          <ProgressRing value={data.leave.rttRemaining} max={data.leave.rttTotal} color="#A8BFA8" label="RTT restants" sublabel={`sur ${data.leave.rttTotal} jours`} />
        </div>
      </div>

      <div style={{ padding: '16px 20px 8px' }}>
        <h2 style={{ margin: '0 0 12px', fontSize: 17, fontWeight: 700 }}>Habilitations</h2>
        {data.canAssign ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {data.catalog.length === 0 && <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: 13 }}>Aucun poste. Créez-en un depuis le planning, puis attribuez l’habilitation ici.</p>}
            {data.catalog.map((item) => (
              <div key={item.id} style={{ background: 'white', borderRadius: 14, padding: '12px 16px', boxShadow: '0 1px 8px rgba(0,0,0,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                <div>
                  <span style={{ background: '#171918', color: 'white', fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 7 }}>{item.code}</span>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 4 }}>{item.name}{item.active ? '' : ' · inactif'}</div>
                </div>
                <button onClick={() => assign(item.id, !item.enabled)} style={{
                  border: 'none', borderRadius: 20, padding: '6px 10px', cursor: 'pointer', fontWeight: 700, fontSize: 12,
                  background: item.enabled ? '#E6F5E7' : '#ECECEC', color: item.enabled ? '#3A7D44' : '#555',
                }}>{item.enabled ? 'Habilité' : 'Non habilité'}</button>
              </div>
            ))}
          </div>
        ) : (
          <>
            {data.habilitations.length === 0 && <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: 13 }}>{data.jobTitle === 'Cadre de santé' ? 'Aucune habilitation de poste. Ce compte supervise l’équipe.' : 'Aucune habilitation. Le cadre doit l’attribuer explicitement.'}</p>}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {data.habilitations.map((item) => (
                <div key={item.post} style={{ background: 'white', borderRadius: 14, padding: '12px 16px', boxShadow: '0 1px 8px rgba(0,0,0,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ background: '#171918', color: 'white', fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 7 }}>{item.post}</span>
                    {item.validLabel && <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{item.validLabel}</span>}
                  </div>
                  <StatusPill label={item.status} variant={item.status === 'Habilité' ? 'success' : item.status === 'Expire bientôt' ? 'warning' : 'neutral'} />
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      <div style={{ padding: '16px 20px 8px' }}>
        <h2 style={{ margin: '0 0 12px', fontSize: 17, fontWeight: 700 }}>Activité récente</h2>
        <div style={{ background: 'white', borderRadius: 20, padding: 16, boxShadow: '0 2px 10px rgba(0,0,0,0.06)' }}>
          {data.activity.length === 0 && <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: 13 }}>Aucune activité.</p>}
          {data.activity.map((item, index) => (
            <div key={`${item.action}${index}`} style={{ display: 'flex', gap: 12, paddingBottom: index < data.activity.length - 1 ? 14 : 0, marginBottom: index < data.activity.length - 1 ? 14 : 0, borderBottom: index < data.activity.length - 1 ? '1px solid var(--border)' : 'none' }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#B8E986', marginTop: 5, flexShrink: 0 }} />
              <div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{item.action}</div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>{item.dateLabel}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {data.viewingSelf && (
        <div style={{ padding: '16px 20px' }}>
          <button onClick={onLogout} style={{ width: '100%', padding: 14, borderRadius: 14, border: '1.5px solid #D98282', background: 'white', color: '#D98282', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
            Se déconnecter
          </button>
        </div>
      )}
    </div>
  );
}
