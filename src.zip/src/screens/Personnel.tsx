import { FormEvent, useEffect, useState } from 'react';
import { api, type PersonnelDetail, type PersonnelInput, type PersonnelMember, type PersonnelType } from '../api';

const QUOTAS = [100, 80, 70, 50];

const emptyDraft = (typeId = 0): PersonnelInput => ({
  firstName: '',
  lastName: '',
  typeId,
  quota: 100,
  arrivalDate: new Date().toISOString().slice(0, 10),
  active: true,
  planningNotes: '',
  loginId: '',
  password: '',
});

function fromPerson(person: PersonnelMember): PersonnelInput {
  return {
    firstName: person.firstName,
    lastName: person.lastName,
    typeId: person.typeId,
    quota: person.quota,
    arrivalDate: person.arrivalDate,
    active: person.active,
    planningNotes: person.planningNotes,
    loginId: person.loginId,
    password: '',
  };
}

export default function Personnel({ onClose, onChanged }: { onClose: () => void; onChanged: () => void }) {
  const [mode, setMode] = useState<'list' | 'form'>('list');
  const [people, setPeople] = useState<PersonnelMember[]>([]);
  const [types, setTypes] = useState<PersonnelType[]>([]);
  const [draft, setDraft] = useState<PersonnelInput>(emptyDraft());
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [detail, setDetail] = useState<PersonnelDetail | null>(null);
  const [newType, setNewType] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmId, setConfirmId] = useState<number | null>(null);

  async function load() {
    const [staff, categories] = await Promise.all([api.personnel(), api.personnelTypes()]);
    setPeople(staff.personnel);
    setTypes(categories.types);
    return categories.types;
  }

  useEffect(() => {
    load().catch((err) => setError(err instanceof Error ? err.message : 'Chargement impossible'));
  }, []);

  function openCreate() {
    setCurrentId(null);
    setDetail(null);
    setConfirmDelete(false);
    setError('');
    setDraft(emptyDraft(types[0]?.id ?? 0));
    setMode('form');
  }

  async function setActive(person: PersonnelMember, active: boolean) {
    setError('');
    try {
      await api.updatePersonnel(person.id, { ...fromPerson(person), active });
      await load();
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Modification impossible');
    }
  }

  function openEdit(person: PersonnelMember) {
    setCurrentId(person.id);
    setDraft(fromPerson(person));
    setDetail(null);
    setConfirmDelete(false);
    setError('');
    setMode('form');
    api.person(person.id).then(setDetail).catch(() => setDetail(null));
  }

  async function save(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const saved = currentId ? await api.updatePersonnel(currentId, draft) : await api.createPersonnel(draft);
      setCurrentId(saved.id);
      setDraft(fromPerson(saved));
      setDetail(saved);
      await load();
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Enregistrement impossible');
    } finally {
      setBusy(false);
    }
  }

  async function remove(id = currentId) {
    if (!id) return;
    setBusy(true);
    setError('');
    try {
      await api.deletePersonnel(id);
      await load();
      onChanged();
      setMode('list');
      setCurrentId(null);
      setConfirmId(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Suppression impossible');
    } finally {
      setBusy(false);
      setConfirmDelete(false);
    }
  }

  async function toggleAgent(postId: number, enabled: boolean) {
    if (!currentId) return;
    setError('');
    try {
      await api.setHabilitation(currentId, postId, enabled);
      setDetail(await api.person(currentId));
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Habilitation impossible');
    }
  }

  async function addType(event: FormEvent) {
    event.preventDefault();
    const name = newType.trim();
    if (!name) return;
    setError('');
    try {
      await api.createPersonnelType(name);
      setNewType('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Catégorie impossible');
    }
  }

  async function renameType(type: PersonnelType, name: string) {
    const next = name.trim();
    if (!next || next === type.name) return;
    setError('');
    try {
      await api.updatePersonnelType(type.id, next);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Catégorie impossible');
    }
  }

  async function removeType(type: PersonnelType) {
    setError('');
    try {
      await api.deletePersonnelType(type.id);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Catégorie impossible');
    }
  }

  return (
    <div style={{
      position: 'fixed', top: 0, bottom: 0, left: '50%', transform: 'translateX(-50%)',
      width: '100%', maxWidth: 430, zIndex: 200, background: 'var(--bg)', overflowY: 'auto',
      paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'calc(24px + env(safe-area-inset-bottom))',
    }} className="scrollbar-hide">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 16px 8px' }}>
        <button onClick={() => mode === 'form' ? setMode('list') : onClose()} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', fontWeight: 600, cursor: 'pointer' }}>
          {mode === 'form' ? 'Retour' : 'Fermer'}
        </button>
        {mode === 'list' && (
          <button onClick={openCreate} style={{ background: '#171918', color: '#B8E986', border: 'none', borderRadius: 12, padding: '8px 12px', fontWeight: 700, cursor: 'pointer' }}>
            + Ajouter un personnel
          </button>
        )}
      </div>
      <h1 style={{ margin: '0 16px 12px', fontSize: 22 }}>{mode === 'list' ? 'Personnel' : currentId ? 'Modifier le personnel' : 'Ajouter un personnel'}</h1>
      {error && <p style={{ margin: '0 16px 10px', color: '#A03030', fontSize: 13 }}>{error}</p>}

      {mode === 'list' ? (
        <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {people.length === 0 && <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: 14 }}>Aucun personnel.</p>}
          {people.map((person) => (
            <div key={person.id} style={{ background: 'white', borderRadius: 16, padding: 14, border: '1.5px solid var(--border)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                <div>
                  <div style={{ fontWeight: 700 }}>{person.firstName} {person.lastName}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 4 }}>
                    {person.typeName} · {person.quota}% · {person.loginId}
                  </div>
                </div>
                <span style={{ alignSelf: 'flex-start', borderRadius: 20, padding: '6px 10px', fontWeight: 700, fontSize: 12, background: person.active ? '#E6F5E7' : '#FDEAEA', color: person.active ? '#3A7D44' : '#A03030' }}>
                  {person.active ? 'Actif' : 'Inactif'}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
                <button onClick={() => openEdit(person)} style={actionButton}>Modifier</button>
                <button onClick={() => setActive(person, !person.active)} style={actionButton}>{person.active ? 'Désactiver' : 'Activer'}</button>
                <button onClick={() => setConfirmId(person.id)} style={{ ...actionButton, color: '#A03030' }}>Supprimer définitivement</button>
              </div>
              {confirmId === person.id && (
                <div style={{ marginTop: 10, background: '#FDEAEA', borderRadius: 12, padding: 12 }}>
                  <p style={{ margin: '0 0 8px', fontSize: 13 }}>Possible seulement s’il n’y a aucun planning ni demande. Sinon, désactivez-le.</p>
                  <button onClick={() => remove(person.id)} style={{ border: 'none', borderRadius: 10, padding: '8px 12px', background: '#A03030', color: 'white', fontWeight: 700, cursor: 'pointer' }}>Confirmer</button>
                </div>
              )}
            </div>
          ))}

          <div>
            <h2 style={{ fontSize: 16, margin: '8px 0' }}>Catégories</h2>
            <p style={{ margin: '0 0 8px', fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.4 }}>
              Technicien, biologiste, stagiaire et les autres catégories se modifient ici.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {types.map((type) => (
                <TypeRow key={type.id} type={type} onRename={(name) => renameType(type, name)} onDelete={() => removeType(type)} />
              ))}
            </div>
            <form onSubmit={addType} style={{ display: 'flex', gap: 8, marginTop: 10 }}>
              <input value={newType} onChange={(event) => setNewType(event.target.value)} placeholder="Nouvelle catégorie" style={inputStyle} />
              <button type="submit" style={{ ...actionButton, background: '#171918', color: '#B8E986', border: 'none' }}>Ajouter</button>
            </form>
          </div>
        </div>
      ) : (
        <form onSubmit={save} style={{ padding: '0 16px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <Field label="Nom" value={draft.lastName} onChange={(lastName) => setDraft({ ...draft, lastName })} />
          <Field label="Prénom" value={draft.firstName} onChange={(firstName) => setDraft({ ...draft, firstName })} />
          <Field label="Identifiant" value={draft.loginId} onChange={(loginId) => setDraft({ ...draft, loginId })} placeholder="lea.rousseau" />
          <Field label="Mot de passe" value={draft.password} onChange={(password) => setDraft({ ...draft, password })} type="password" placeholder={currentId ? 'Laisser vide pour ne pas changer' : 'Au moins 4 caractères'} />
          <p style={{ margin: 0, fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.4 }}>
            Le technicien se connecte à LAB avec cet identifiant et ce mot de passe.
          </p>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <span style={labelStyle}>Type de personnel</span>
            <select value={draft.typeId} onChange={(event) => setDraft({ ...draft, typeId: Number(event.target.value) })} style={inputStyle}>
              {types.map((type) => <option key={type.id} value={type.id}>{type.name}</option>)}
            </select>
          </label>
          <div>
            <div style={{ ...labelStyle, marginBottom: 6 }}>Quotité de travail</div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
              {QUOTAS.map((quota) => (
                <button key={quota} type="button" onClick={() => setDraft({ ...draft, quota })} style={{
                  ...actionButton,
                  background: draft.quota === quota ? '#171918' : 'white',
                  color: draft.quota === quota ? '#B8E986' : '#171918',
                }}>{quota} %</button>
              ))}
              <input
                type="number"
                min={1}
                max={100}
                value={draft.quota}
                onChange={(event) => setDraft({ ...draft, quota: Number(event.target.value) })}
                style={{ ...inputStyle, width: 80 }}
              />
            </div>
          </div>
          <Field label="Date d’arrivée" value={draft.arrivalDate} onChange={(arrivalDate) => setDraft({ ...draft, arrivalDate })} type="date" />
          <button type="button" onClick={() => setDraft({ ...draft, active: !draft.active })} style={{
            alignSelf: 'flex-start', border: 'none', borderRadius: 20, padding: '8px 12px', cursor: 'pointer', fontWeight: 700,
            background: draft.active ? '#E6F5E7' : '#FDEAEA', color: draft.active ? '#3A7D44' : '#A03030',
          }}>{draft.active ? 'Actif' : 'Inactif'}</button>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <span style={labelStyle}>Informations de planification</span>
            <textarea value={draft.planningNotes} onChange={(event) => setDraft({ ...draft, planningNotes: event.target.value })} placeholder="Contraintes, disponibilité, remarques" style={{ ...inputStyle, minHeight: 72, resize: 'vertical' }} />
          </label>
          <p style={{ margin: 0, fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.4 }}>
            Un personnel créé n’est habilité à aucun poste. La quotité limite le nombre de jours travaillés lors de la génération.
          </p>
          <button type="submit" disabled={busy} style={{ padding: 14, borderRadius: 14, border: 'none', background: '#171918', color: '#B8E986', fontWeight: 700, cursor: 'pointer' }}>
            {busy ? 'Enregistrement…' : currentId ? 'Enregistrer' : 'Ajouter le personnel'}
          </button>

          {currentId && detail && (
            <div>
              <h2 style={{ fontSize: 16, margin: '8px 0' }}>Habilitations</h2>
              {detail.posts.length === 0 && <p style={{ margin: 0, fontSize: 13, color: 'var(--text-secondary)' }}>Aucun poste. Créez-en un, puis attribuez l’habilitation ici.</p>}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {detail.posts.map((post) => (
                  <div key={post.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'white', borderRadius: 12, padding: '10px 12px' }}>
                    <span style={{ fontSize: 14 }}>{post.code}{post.active ? '' : ' · inactif'}</span>
                    <button type="button" onClick={() => toggleAgent(post.id, !post.enabled)} style={{
                      border: 'none', borderRadius: 20, padding: '6px 10px', cursor: 'pointer', fontWeight: 700, fontSize: 12,
                      background: post.enabled ? '#E6F5E7' : '#ECECEC', color: post.enabled ? '#3A7D44' : '#555',
                    }}>{post.enabled ? 'Habilité' : 'Non habilité'}</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {currentId && !confirmDelete && (
            <button type="button" onClick={() => setConfirmDelete(true)} style={{ background: 'none', border: 'none', color: '#A03030', fontWeight: 700, cursor: 'pointer' }}>
              Supprimer définitivement
            </button>
          )}
          {confirmDelete && (
            <div style={{ background: '#FDEAEA', borderRadius: 12, padding: 12 }}>
              <p style={{ margin: '0 0 8px', fontSize: 13 }}>La suppression définitive n’est possible que sans historique de planning. Sinon, désactivez le personnel.</p>
              <button type="button" onClick={() => remove()} style={{ border: 'none', borderRadius: 10, padding: '8px 12px', background: '#A03030', color: 'white', fontWeight: 700, cursor: 'pointer' }}>Confirmer la suppression</button>
            </div>
          )}
        </form>
      )}
    </div>
  );
}

function TypeRow({ type, onRename, onDelete }: { type: PersonnelType; onRename: (name: string) => void; onDelete: () => void }) {
  const [name, setName] = useState(type.name);
  return (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
      <input value={name} onChange={(event) => setName(event.target.value)} onBlur={() => onRename(name)} style={inputStyle} />
      <button type="button" onClick={onDelete} style={{ ...actionButton, color: '#A03030' }}>Retirer</button>
    </div>
  );
}

function Field({ label, value, onChange, type = 'text', placeholder }: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={labelStyle}>{label}</span>
      <input value={value} type={type} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} style={inputStyle} />
    </label>
  );
}

const labelStyle = { fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' } as const;
const inputStyle = {
  border: '1.5px solid var(--border)', background: 'white', borderRadius: 14, padding: '12px 14px', fontSize: 15, outline: 'none', width: '100%',
} as const;
const actionButton = {
  background: 'white', border: '1.5px solid var(--border)', borderRadius: 12, padding: '8px 12px', fontSize: 13, fontWeight: 700, color: '#171918', cursor: 'pointer',
} as const;
