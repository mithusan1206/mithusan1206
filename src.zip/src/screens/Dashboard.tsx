import { useEffect, useState } from 'react';
import { api, type DashboardData } from '../api';
import Avatar from '../components/Avatar';
import StatusPill from '../components/StatusPill';

const tones = {
  sage: { color: '#A8BFA8', bg: '#EFF5EF' },
  neon: { color: '#B8E986', bg: '#F2FAE5' },
  pink: { color: '#F3C6CE', bg: '#FEF2F4' },
  orange: { color: '#F4B183', bg: '#FEF3EC' },
};

export default function Dashboard({ onOpenPlanning, onOpenAccount }: { onOpenPlanning: () => void; onOpenAccount?: () => void }) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState<number | null>(null);

  async function load() {
    try {
      setData(await api.dashboard());
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Chargement impossible');
    }
  }

  useEffect(() => { load(); }, []);

  async function decide(id: number, action: 'approve' | 'reject') {
    setBusyId(id);
    try {
      await api.decide(id, action);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action impossible');
    } finally {
      setBusyId(null);
    }
  }

  if (!data) {
    return <p style={{ padding: 28, color: 'var(--text-secondary)' }}>{error || 'Chargement…'}</p>;
  }

  return (
    <div style={{ paddingBottom: 100 }}>
      <div style={{ padding: '28px 20px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
        <div>
          <p style={{ margin: 0, fontSize: 13, color: 'var(--text-secondary)', fontWeight: 500 }}>{data.todayLabel}</p>
          <h1 style={{ margin: '4px 0 2px', fontSize: 24, fontWeight: 700 }}>{data.greeting}</h1>
          <p style={{ margin: 0, fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.4 }}>{data.subtitle}</p>
        </div>
        {onOpenAccount ? (
          <button type="button" onClick={onOpenAccount} aria-label="Mon profil" style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}>
            <Avatar name={data.viewerName} size={40} />
          </button>
        ) : (
          <Avatar name={data.viewerName} size={40} />
        )}
      </div>

      {error && <p style={{ margin: '0 20px 8px', color: '#A03030', fontSize: 13 }}>{error}</p>}

      <div style={{ padding: '8px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {data.kpis.map((kpi) => {
          const tone = tones[kpi.tone];
          return (
            <div key={kpi.label} style={{ background: tone.bg, borderRadius: 20, padding: 16, border: `1.5px solid ${tone.color}40` }}>
              <div style={{ fontSize: 24, fontWeight: 700, lineHeight: 1 }}>{kpi.value}</div>
              <div style={{ fontSize: 12, fontWeight: 600, marginTop: 4 }}>{kpi.label}</div>
              <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>{kpi.sub}</div>
              <div style={{ width: 28, height: 4, background: tone.color, borderRadius: 4, marginTop: 10 }} />
            </div>
          );
        })}
      </div>

      <div style={{ padding: '16px 20px 8px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700 }}>Planning du jour</h2>
          <button onClick={onOpenPlanning} style={{ fontSize: 12, color: 'var(--text-secondary)', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600 }}>Voir tout</button>
        </div>
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 8 }} className="scrollbar-hide">
          {data.planning.map((person) => (
            <div key={person.userId} style={{ background: 'white', borderRadius: 16, padding: 14, minWidth: 130, boxShadow: '0 2px 10px rgba(0,0,0,0.06)', flexShrink: 0 }}>
              <Avatar name={person.name} size={40} />
              <div style={{ marginTop: 10, fontSize: 13, fontWeight: 600 }}>{person.name.split(' ')[0]}</div>
              <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{person.name.split(' ').slice(1).join(' ')}</div>
              <div style={{ marginTop: 8, background: '#171918', color: 'white', fontSize: 11, fontWeight: 700, padding: '3px 8px', borderRadius: 8, display: 'inline-block' }}>{person.post}</div>
              <div style={{ fontSize: 10, color: 'var(--text-secondary)', marginTop: 6 }}>{person.time}</div>
              {!person.habilite && <div style={{ marginTop: 6 }}><StatusPill label="Non habilité" variant="warning" /></div>}
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '8px 20px' }}>
        <h2 style={{ margin: '0 0 14px', fontSize: 17, fontWeight: 700 }}>{data.coverageTitle}</h2>
        <div style={{ background: 'white', borderRadius: 20, padding: 16, boxShadow: '0 2px 10px rgba(0,0,0,0.06)' }}>
        {data.coverage.length === 0 ? (
          <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: 13 }}>Aucun poste. Le cadre peut en créer un depuis le planning.</p>
        ) : (
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, height: 90 }}>
            {data.coverage.map((post) => (
              <div key={post.name} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                <div style={{
                  width: '100%',
                  height: Math.max(4, post.coverage * 0.7),
                  background: post.coverage === 100 ? '#8DBF91' : post.coverage >= 50 ? '#E8AA72' : '#D98282',
                  borderRadius: '6px 6px 4px 4px',
                }} />
                <span style={{ fontSize: 9, color: 'var(--text-secondary)', fontWeight: 600, textAlign: 'center' }}>{post.name}</span>
              </div>
            ))}
          </div>
        )}
        </div>
      </div>

      <div style={{ padding: '8px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700 }}>Demandes en attente</h2>
          <span style={{ fontSize: 12, background: '#FEF2F4', color: '#A03030', fontWeight: 700, padding: '2px 8px', borderRadius: 20 }}>{data.pendingBadge}</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {data.requests.length === 0 && <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: 13 }}>Aucune demande en attente.</p>}
          {data.requests.map((item) => (
            <div key={item.id} style={{ background: 'white', borderRadius: 16, padding: '14px 16px', boxShadow: '0 2px 10px rgba(0,0,0,0.06)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Avatar name={item.name} size={40} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{item.dates} · {item.reason}</div>
                </div>
                <span style={{ background: '#171918', color: 'white', fontSize: 11, fontWeight: 700, padding: '3px 8px', borderRadius: 8 }}>{item.type}</span>
              </div>
              {item.waitingFor && <div style={{ fontSize: 12, color: '#A06020', fontWeight: 700, marginTop: 8 }}>En attente de {item.waitingFor}</div>}
              {data.canValidate && item.status === 'En attente' && (
                <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                  <button disabled={busyId === item.id} onClick={() => decide(item.id, 'reject')} style={rejectStyle}>Refuser</button>
                  <button disabled={busyId === item.id} onClick={() => decide(item.id, 'approve')} style={approveStyle}>{item.type === 'Échange' ? 'Approuver' : 'Valider'}</button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '8px 20px' }}>
        <h2 style={{ margin: '0 0 12px', fontSize: 17, fontWeight: 700 }}>Alertes</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {data.alerts.length === 0 && <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: 13 }}>Aucune alerte.</p>}
          {data.alerts.map((alert) => (
            <div key={alert.id} style={{ background: 'white', borderRadius: 16, padding: '14px 16px', boxShadow: '0 2px 10px rgba(0,0,0,0.06)', borderLeft: `3px solid ${alert.level === 'Urgent' ? '#D98282' : '#E8AA72'}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: alert.level === 'Urgent' ? '#D98282' : '#E8AA72', marginBottom: 3 }}>{alert.level}</div>
                  <div style={{ fontSize: 13, lineHeight: 1.4 }}>{alert.message}</div>
                </div>
                <span style={{ fontSize: 11, color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{alert.timeLabel}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const rejectStyle = {
  flex: 1, padding: '9px', borderRadius: 12, border: '1.5px solid #D98282',
  background: 'white', color: '#D98282', fontSize: 13, fontWeight: 600, cursor: 'pointer',
} as const;

const approveStyle = {
  flex: 1, padding: '9px', borderRadius: 12, border: 'none',
  background: '#B8E986', color: '#171918', fontSize: 13, fontWeight: 700, cursor: 'pointer',
} as const;
