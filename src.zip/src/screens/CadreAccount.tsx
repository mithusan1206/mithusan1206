import { FormEvent, useEffect, useState } from 'react';
import { api, type CadreAccount } from '../api';
import Avatar from '../components/Avatar';

export default function CadreAccountScreen({ onClose }: { onClose: () => void }) {
  const [account, setAccount] = useState<CadreAccount | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [editingId, setEditingId] = useState(false);
  const [loginId, setLoginId] = useState('');
  const [confirmId, setConfirmId] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.account()
      .then((result) => {
        setAccount(result);
        setLoginId(result.loginId);
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'Chargement impossible'));
  }, []);

  async function saveId(event: FormEvent) {
    event.preventDefault();
    if (!account) return;
    const next = loginId.trim().toLowerCase();
    if (next === account.loginId) {
      setEditingId(false);
      return;
    }
    setConfirmId(true);
  }

  async function confirmLoginId() {
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const saved = await api.changeLoginId(loginId.trim());
      setAccount(saved);
      setLoginId(saved.loginId);
      setEditingId(false);
      setConfirmId(false);
      setNotice('Identifiant enregistré.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Identifiant impossible');
    } finally {
      setBusy(false);
    }
  }

  async function savePassword(event: FormEvent) {
    event.preventDefault();
    setError('');
    setNotice('');
    if (newPassword !== confirmPassword) {
      setError('La confirmation ne correspond pas au nouveau mot de passe.');
      return;
    }
    if (newPassword.length < 8 || !/[A-Za-z]/.test(newPassword) || !/\d/.test(newPassword)) {
      setError('Le nouveau mot de passe doit contenir au moins 8 caractères, une lettre et un chiffre.');
      return;
    }
    if (newPassword === currentPassword) {
      setError('Choisissez un mot de passe différent de l’ancien.');
      return;
    }
    setBusy(true);
    try {
      await api.changePassword(currentPassword, newPassword);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setNotice('Mot de passe modifié.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Mot de passe impossible');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{
      position: 'fixed', top: 0, bottom: 0, left: '50%', transform: 'translateX(-50%)',
      width: '100%', maxWidth: 430, zIndex: 200, background: 'var(--bg)', overflowY: 'auto',
      paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'calc(24px + env(safe-area-inset-bottom))',
    }} className="scrollbar-hide">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 16px 8px' }}>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', fontWeight: 600, cursor: 'pointer' }}>Fermer</button>
      </div>
      <h1 style={{ margin: '0 16px 16px', fontSize: 22 }}>Mon profil</h1>
      {error && <p style={{ margin: '0 16px 10px', color: '#A03030', fontSize: 13 }}>{error}</p>}
      {notice && <p style={{ margin: '0 16px 10px', color: '#3A7D44', fontSize: 13 }}>{notice}</p>}

      {account && (
        <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0' }}>
            <Avatar name={account.name} size={48} />
          </div>
          <Info label="Nom" value={account.lastName} />
          <Info label="Prénom" value={account.firstName} />
          <div style={card}>
            <Locked label="Rôle" value={account.roleLabel} />
          </div>
          <Info label="Email" value={account.email} />
          <Info label="Laboratoire / service" value={account.labName} />

          <form onSubmit={saveId} style={card}>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>ID de connexion</div>
            {editingId ? (
              <input value={loginId} onChange={(event) => setLoginId(event.target.value)} style={inputStyle} />
            ) : (
              <div style={{ fontSize: 15, fontWeight: 700 }}>{account.loginId}</div>
            )}
            {!editingId && (
              <button type="button" onClick={() => { setEditingId(true); setConfirmId(false); }} style={darkButton}>Modifier</button>
            )}
            {editingId && !confirmId && (
              <button type="submit" style={darkButton}>Enregistrer</button>
            )}
            {confirmId && (
              <div style={{ background: '#F7F6F1', borderRadius: 12, padding: 12 }}>
                <p style={{ margin: '0 0 8px', fontSize: 13 }}>Confirmer l’identifiant {loginId.trim().toLowerCase()} ?</p>
                <button type="button" onClick={confirmLoginId} disabled={busy} style={darkButton}>Confirmer</button>
              </div>
            )}
          </form>

          <form onSubmit={savePassword} style={card}>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>Mot de passe</div>
            <div style={{ fontSize: 15, letterSpacing: '0.2em' }}>••••••••</div>
            <Secret label="Ancien mot de passe" value={currentPassword} onChange={setCurrentPassword} />
            <Secret label="Nouveau mot de passe" value={newPassword} onChange={setNewPassword} />
            <Secret label="Confirmer le nouveau mot de passe" value={confirmPassword} onChange={setConfirmPassword} />
            <button type="submit" disabled={busy} style={darkButton}>{busy ? 'Enregistrement…' : 'Modifier le mot de passe'}</button>
          </form>

          <div style={card}>
            <Locked label="Permissions" value={account.permissions.join(', ')} />
            <p style={{ margin: 0, fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.4 }}>
              Le rôle et les permissions ne se modifient pas depuis ce profil.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div style={card}>
      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 700 }}>{value}</div>
    </div>
  );
}

function Locked({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>{label}</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }}>
        <div style={{ fontSize: 15, fontWeight: 700 }}>{value}</div>
        <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)' }} aria-label="Verrouillé">Verrouillé</span>
      </div>
    </div>
  );
}

function Eye({ open }: { open: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z" stroke="#171918" strokeWidth="1.8" />
      <circle cx="12" cy="12" r="3" stroke="#171918" strokeWidth="1.8" />
      {open && <path d="M4 20L20 4" stroke="#171918" strokeWidth="1.8" />}
    </svg>
  );
}

function Secret({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  const [visible, setVisible] = useState(false);
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>{label}</span>
      <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <input type={visible ? 'text' : 'password'} value={value} onChange={(event) => onChange(event.target.value)} style={{ ...inputStyle, flex: 1 }} />
        <button type="button" onClick={() => setVisible((current) => !current)} aria-label={visible ? 'Masquer le mot de passe' : 'Afficher le mot de passe'} style={{
          width: 40, height: 40, borderRadius: 12, border: '1.5px solid var(--border)', background: 'white', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Eye open={visible} />
        </button>
      </span>
    </label>
  );
}

const card = {
  background: 'white', borderRadius: 16, padding: 14, border: '1.5px solid var(--border)',
  display: 'flex', flexDirection: 'column', gap: 8,
} as const;

const inputStyle = {
  border: '1.5px solid var(--border)', background: 'white', borderRadius: 14, padding: '12px 14px', fontSize: 15, outline: 'none',
} as const;

const darkButton = {
  alignSelf: 'flex-start', background: '#171918', color: '#B8E986', border: 'none', borderRadius: 12,
  padding: '8px 12px', fontWeight: 700, cursor: 'pointer',
} as const;
