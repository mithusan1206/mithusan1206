import { useEffect, useState } from 'react';
import { api, type TeamData } from '../api';
import Avatar from '../components/Avatar';
import StatusPill from '../components/StatusPill';
import ExchangePlanning from './ExchangePlanning';

type Filter = 'Tous' | 'Présents' | 'Absents' | 'Habilités' | 'Habilitations expirantes';
const filters: Filter[] = ['Tous', 'Présents', 'Absents', 'Habilités', 'Habilitations expirantes'];

function variant(status: string): 'success' | 'danger' | 'warning' | 'neutral' {
  if (status === 'present') return 'success';
  if (status === 'absent') return 'danger';
  if (status === 'leave') return 'warning';
  return 'neutral';
}

export default function Team({ isCadre, viewerId, onOpenProfile }: { isCadre: boolean; viewerId: number; onOpenProfile: (id: number) => void }) {
  const [filter, setFilter] = useState<Filter>('Tous');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<number | null>(null);
  const [exchangeWith, setExchangeWith] = useState<{ id: number; name: string } | null>(null);
  const [data, setData] = useState<TeamData | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const handle = setTimeout(() => {
      api.team(search, filter)
        .then((result) => { setData(result); setError(''); })
        .catch((err) => setError(err instanceof Error ? err.message : 'Chargement impossible'));
    }, 150);
    return () => clearTimeout(handle);
  }, [search, filter]);

  return (
    <div style={{ paddingBottom: 100 }}>
      <div style={{ padding: '28px 20px 12px' }}>
        <h1 style={{ margin: '0 0 14px', fontSize: 24, fontWeight: 700 }}>Équipe</h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'white', borderRadius: 14, padding: '10px 14px', border: '1.5px solid var(--border)' }}>
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Rechercher un technicien..."
            style={{ border: 'none', outline: 'none', flex: 1, fontSize: 14, background: 'transparent' }}
          />
        </div>
      </div>

      <div style={{ padding: '0 20px 16px', display: 'flex', gap: 8, overflowX: 'auto' }} className="scrollbar-hide">
        {filters.map((item) => (
          <button key={item} onClick={() => setFilter(item)} style={{
            padding: '7px 14px', borderRadius: 20, border: 'none', cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0,
            background: filter === item ? '#171918' : 'white', color: filter === item ? 'white' : 'var(--text-secondary)',
            fontSize: 12, fontWeight: 600,
          }}>{item}</button>
        ))}
      </div>

      {data && (
        <div style={{ padding: '0 20px 12px', fontSize: 13, color: 'var(--text-secondary)' }}>
          {data.members.length} membre{data.members.length > 1 ? 's' : ''} · {data.counts.present} présents · {data.counts.absent} absents
          {data.counts.off > 0 ? ` · ${data.counts.off} en repos` : ''}
        </div>
      )}
      {error && <p style={{ margin: '0 20px', color: '#A03030', fontSize: 13 }}>{error}</p>}

      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {data?.members.map((member) => (
          <div key={member.id} onClick={() => {
            if (!isCadre && member.id !== viewerId) {
              setExchangeWith({ id: member.id, name: member.name });
              return;
            }
            setSelected(selected === member.id ? null : member.id);
          }} style={{
            background: 'white', borderRadius: 16, padding: '14px 16px', boxShadow: '0 2px 10px rgba(0,0,0,0.06)', cursor: 'pointer',
            border: selected === member.id ? '1.5px solid #B8E986' : '1.5px solid transparent',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ position: 'relative' }}>
                <Avatar name={member.name} size={48} />
                <div style={{
                  position: 'absolute', bottom: 2, right: 2, width: 10, height: 10, borderRadius: '50%',
                  background: member.status === 'present' ? '#8DBF91' : member.status === 'off' ? '#A8BFA8' : '#D98282',
                  border: '1.5px solid white',
                }} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>{member.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 1 }}>{member.role}</div>
                {member.post !== '—' && <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 1 }}>Poste : <strong>{member.post}</strong></div>}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                <StatusPill label={member.statusLabel} variant={variant(member.status)} />
                {member.expiring && <StatusPill label="Expirante" variant="warning" />}
              </div>
            </div>
            {selected === member.id && (
              <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{member.habilitations} habilitation{member.habilitations > 1 ? 's' : ''} validée{member.habilitations > 1 ? 's' : ''}</span>
                {isCadre && (
                  <button onClick={(event) => { event.stopPropagation(); onOpenProfile(member.id); }} style={{
                    padding: '7px 14px', borderRadius: 10, border: 'none', background: '#171918', color: '#B8E986', fontSize: 12, fontWeight: 700, cursor: 'pointer',
                  }}>Voir profil</button>
                )}
              </div>
            )}
          </div>
        ))}
        {data && data.members.length === 0 && <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>Aucun membre pour ce filtre.</p>}
      </div>
      {exchangeWith && (
        <ExchangePlanning
          partnerId={exchangeWith.id}
          partnerName={exchangeWith.name}
          viewerId={viewerId}
          onClose={() => setExchangeWith(null)}
        />
      )}
    </div>
  );
}
