import { useEffect, useState } from 'react';
import { api, type LabPost, type PlanningData } from '../api';
import { colorById } from '../palette';

const OFF = new Set(['R.H.', 'CA', 'RTT', 'J.F.', 'ABS']);
const SWAPPABLE = new Set(['CA', 'RTT']);
const WEEK = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];
const MONTHS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const OFF_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  'R.H.': { bg: '#ECEFF1', text: '#607D8B', border: '#CFD8DC' },
  CA: { bg: '#B2EBF2', text: '#006064', border: '#80DEEA' },
  RTT: { bg: '#B2DFDB', text: '#004D40', border: '#80CBC4' },
  'J.F.': { bg: '#FFF8E1', text: '#F57F17', border: '#FFECB3' },
  ABS: { bg: '#FFCDD2', text: '#B71C1C', border: '#EF9A9A' },
};

function iso(date: Date) {
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${date.getFullYear()}-${month}-${day}`;
}

function todayIso() {
  return iso(new Date());
}

function swappable(code: string) {
  return Boolean(code) && code !== '—' && (!OFF.has(code) || SWAPPABLE.has(code));
}

function paint(code: string, posts: LabPost[]) {
  const post = posts.find((item) => item.code === code);
  if (post) return colorById(post.color);
  return OFF_COLORS[code] ?? { bg: '#F5F5F5', text: '#666', border: '#E0E0E0' };
}

export default function ExchangePlanning({
  partnerId,
  partnerName,
  viewerId,
  requestId,
  initialStart = '',
  initialEnd = '',
  initialReason = '',
  onClose,
}: {
  partnerId: number;
  partnerName: string;
  viewerId: number;
  requestId?: number;
  initialStart?: string;
  initialEnd?: string;
  initialReason?: string;
  onClose: () => void;
}) {
  const [cursor, setCursor] = useState(() => (initialStart ? parseIso(initialStart) : new Date()));
  const [data, setData] = useState<PlanningData | null>(null);
  const [start, setStart] = useState(initialStart);
  const [end, setEnd] = useState(initialEnd && initialEnd !== initialStart ? initialEnd : '');
  const [reason, setReason] = useState(initialReason);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const monthFrom = iso(new Date(cursor.getFullYear(), cursor.getMonth(), 1));
  const monthTo = iso(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0));
  const spanStart = start && end ? (start < end ? start : end) : start;
  const spanEnd = start && end ? (start < end ? end : start) : start;
  const from = spanStart && spanStart < monthFrom ? spanStart : monthFrom;
  const to = spanEnd && spanEnd > monthTo ? spanEnd : monthTo;

  useEffect(() => {
    api.planning(from, to)
      .then((result) => { setData(result); setError(''); })
      .catch((err) => setError(err instanceof Error ? err.message : 'Chargement impossible'));
  }, [from, to]);

  const codes = new Map((data?.cells ?? []).map((cell) => [`${cell.userId}|${cell.date}`, cell.code]));
  const posts = data?.posts ?? [];
  const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
  const lead = (first.getDay() + 6) % 7;
  const count = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
  const cells = [
    ...Array.from({ length: lead }, () => null),
    ...Array.from({ length: count }, (_, index) => new Date(cursor.getFullYear(), cursor.getMonth(), index + 1)),
  ];
  const rangeStart = spanStart;
  const rangeEnd = spanEnd;

  const chosen: { date: string; mine: string; hers: string }[] = [];
  if (rangeStart && rangeEnd) {
    const cursorDay = new Date(`${rangeStart}T12:00:00`);
    const last = new Date(`${rangeEnd}T12:00:00`);
    while (cursorDay <= last) {
      const date = iso(cursorDay);
      const mine = codes.get(`${viewerId}|${date}`) ?? '—';
      const hers = codes.get(`${partnerId}|${date}`) ?? '—';
      if (swappable(mine) || swappable(hers)) chosen.push({ date, mine, hers });
      cursorDay.setDate(cursorDay.getDate() + 1);
    }
  }

  function pick(date: string) {
    if (date < todayIso()) return;
    if (!start || (start && end)) {
      setStart(date);
      setEnd('');
      return;
    }
    setEnd(date);
  }

  async function send() {
    if (!rangeStart || !rangeEnd) return;
    setBusy(true);
    try {
      const body = {
        partnerId,
        startDate: rangeStart,
        endDate: rangeEnd,
        reason: reason.trim() || 'Échange de poste',
      };
      if (requestId) await api.updateExchange(requestId, body);
      else await api.createExchange(body);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Demande impossible');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{
      position: 'fixed', top: 0, bottom: 0, left: '50%', transform: 'translateX(-50%)',
      width: '100%', maxWidth: 430, zIndex: 200, background: 'var(--bg)', overflowY: 'auto',
      paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'calc(24px + env(safe-area-inset-bottom))',
    }} className="scrollbar-hide">
      <div style={{ display: 'flex', alignItems: 'center', padding: '16px 12px 8px' }}>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', fontWeight: 600, cursor: 'pointer' }}>Fermer</button>
      </div>
      <h1 style={{ margin: '0 16px 4px', fontSize: 22 }}>{partnerName}</h1>
      <p style={{ margin: '0 16px 12px', fontSize: 13, color: 'var(--text-secondary)' }}>
        Touchez le premier jour, puis le dernier jour de l’échange.
      </p>
      <div style={{ display: 'flex', alignItems: 'center', padding: '0 12px 10px' }}>
        <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))} style={nav}>‹</button>
        <div style={{ flex: 1, textAlign: 'center', fontWeight: 700 }}>{MONTHS[cursor.getMonth()]} {cursor.getFullYear()}</div>
        <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))} style={nav}>›</button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, padding: '0 12px' }}>
        {WEEK.map((label, index) => (
          <div key={`${label}-${index}`} style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: 'var(--text-secondary)' }}>{label}</div>
        ))}
        {cells.map((day, index) => {
          if (!day) return <div key={`empty-${index}`} />;
          const date = iso(day);
          const code = codes.get(`${partnerId}|${date}`) ?? '—';
          const color = paint(code, posts);
          const past = date < todayIso();
          const inside = Boolean(rangeStart && rangeEnd && date >= rangeStart && date <= rangeEnd);
          const edge = date === rangeStart || date === rangeEnd;
          return (
            <button
              key={date}
              type="button"
              disabled={past}
              onClick={() => pick(date)}
              style={{
                minHeight: 52, borderRadius: 10, border: edge ? '2px solid #171918' : `1px solid ${color.border}`,
                background: inside ? '#B8E986' : color.bg, color: inside && !edge ? '#171918' : color.text,
                opacity: past ? 0.35 : 1, cursor: past ? 'default' : 'pointer', padding: 2,
              }}
            >
              <div style={{ fontSize: 11, fontWeight: 800 }}>{day.getDate()}</div>
              <div style={{ fontSize: 9, fontWeight: 700 }}>{code}</div>
            </button>
          );
        })}
      </div>
      <div style={{ padding: '16px 16px 0', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {!rangeStart && <p style={{ margin: 0, fontSize: 13, color: 'var(--text-secondary)' }}>Aucun jour choisi.</p>}
        {rangeStart && !end && <p style={{ margin: 0, fontSize: 13 }}>Début : {dayLabel(rangeStart)}. Touchez le dernier jour, ou envoyez pour ce seul jour.</p>}
        {chosen.map((day) => (
          <div key={day.date} style={{ background: 'white', borderRadius: 12, padding: '8px 12px', fontSize: 13 }}>
            {dayLabel(day.date)} · Vous : {day.mine} → {partnerName.split(' ')[0]} : {day.hers}
          </div>
        ))}
        {rangeStart && rangeEnd && chosen.length === 0 && (
          <p style={{ margin: 0, fontSize: 13, color: '#A03030' }}>Aucun poste, CA ou RTT à échanger sur cette période.</p>
        )}
        <input value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Motif" style={{ border: '1.5px solid var(--border)', borderRadius: 12, padding: '10px 12px', fontSize: 14 }} />
        {error && <p style={{ margin: 0, color: '#A03030', fontSize: 13 }}>{error}</p>}
        <button
          type="button"
          disabled={busy || !rangeStart || chosen.length === 0}
          onClick={send}
          style={{ background: '#171918', color: '#B8E986', border: 'none', borderRadius: 12, padding: '12px', fontWeight: 700, cursor: 'pointer' }}
        >
          {busy ? 'Envoi…' : requestId ? 'Enregistrer' : 'Envoyer la demande'}
        </button>
      </div>
    </div>
  );
}

function parseIso(value: string) {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day);
}

function dayLabel(value: string) {
  const [year, month, day] = value.split('-').map(Number);
  const months = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
  return `${day} ${months[month - 1]} ${year}`;
}

const nav = {
  background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: '#737873', padding: 8,
} as const;
