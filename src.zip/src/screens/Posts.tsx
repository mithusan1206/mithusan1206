import { FormEvent, useEffect, useState } from 'react';
import { api, type LabPost, type LabPostDetail } from '../api';
import { POST_COLORS, colorById } from '../palette';

type Draft = {
  name: string;
  code: string;
  description: string;
  startTime: string;
  endTime: string;
  color: string;
  active: boolean;
};

const emptyDraft = (): Draft => ({
  name: '',
  code: '',
  description: '',
  startTime: '08:00',
  endTime: '17:00',
  color: 'sage',
  active: true,
});

function fromPost(post: LabPost): Draft {
  return {
    name: post.name,
    code: post.code,
    description: post.description,
    startTime: post.startTime,
    endTime: post.endTime,
    color: post.color,
    active: post.active,
  };
}

export default function Posts({ initial, editing, onClose, onChanged }: {
  initial: 'create' | 'list';
  editing: LabPost | null;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [mode, setMode] = useState<'list' | 'form'>(initial === 'list' ? 'list' : 'form');
  const [draft, setDraft] = useState<Draft>(editing ? fromPost(editing) : emptyDraft());
  const [currentId, setCurrentId] = useState<number | null>(editing?.id ?? null);
  const [posts, setPosts] = useState<LabPost[]>([]);
  const [detail, setDetail] = useState<LabPostDetail | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  async function load() {
    const result = await api.posts();
    setPosts(result.posts);
  }

  useEffect(() => {
    load().catch((err) => setError(err instanceof Error ? err.message : 'Chargement impossible'));
    if (currentId) api.post(currentId).then(setDetail).catch(() => setDetail(null));
  }, []);

  function openCreate() {
    setCurrentId(null);
    setDraft(emptyDraft());
    setDetail(null);
    setConfirmDelete(false);
    setError('');
    setMode('form');
  }

  function openEdit(post: LabPost) {
    setCurrentId(post.id);
    setDraft(fromPost(post));
    setDetail(null);
    setConfirmDelete(false);
    setError('');
    setMode('form');
    api.post(post.id).then(setDetail).catch(() => setDetail(null));
  }

  async function save(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const saved = currentId ? await api.updatePost(currentId, draft) : await api.createPost(draft);
      setCurrentId(saved.id);
      setDraft(fromPost(saved));
      await load();
      setDetail(await api.post(saved.id));
      onChanged();
      if (!currentId) setMode('form');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Enregistrement impossible');
    } finally {
      setBusy(false);
    }
  }

  async function toggleActive(post: LabPost) {
    setError('');
    try {
      await api.updatePost(post.id, { ...fromPost(post), active: !post.active });
      await load();
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Modification impossible');
    }
  }

  async function remove() {
    if (!currentId) return;
    setBusy(true);
    try {
      await api.deletePost(currentId);
      await load();
      onChanged();
      setMode('list');
      setCurrentId(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Suppression impossible');
    } finally {
      setBusy(false);
      setConfirmDelete(false);
    }
  }

  async function toggleAgent(userId: number, enabled: boolean) {
    if (!currentId) return;
    setError('');
    try {
      await api.setHabilitation(userId, currentId, enabled);
      setDetail(await api.post(currentId));
      await load();
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Habilitation impossible');
    }
  }

  return (
    <div style={{
      position: 'fixed', top: 0, bottom: 0, left: '50%', transform: 'translateX(-50%)',
      width: '100%', maxWidth: 430, zIndex: 200, background: 'var(--bg)', overflowY: 'auto',
      paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'calc(24px + env(safe-area-inset-bottom))',
    }} className="scrollbar-hide">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 16px 8px' }}>
        <button onClick={() => mode === 'form' && initial === 'list' ? setMode('list') : onClose()} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', fontWeight: 600, cursor: 'pointer' }}>
          {mode === 'form' && initial === 'list' ? 'Retour' : 'Fermer'}
        </button>
        {mode === 'list' && <button onClick={openCreate} style={{ background: '#171918', color: '#B8E986', border: 'none', borderRadius: 12, padding: '8px 12px', fontWeight: 700, cursor: 'pointer' }}>Créer un poste</button>}
      </div>
      <h1 style={{ margin: '0 16px 12px', fontSize: 22 }}>{mode === 'list' ? 'Postes' : currentId ? 'Modifier le poste' : 'Créer un poste'}</h1>
      {error && <p style={{ margin: '0 16px 10px', color: '#A03030', fontSize: 13 }}>{error}</p>}

      {mode === 'list' ? (
        <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {posts.length === 0 && <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Aucun poste. Créez le premier poste du laboratoire.</p>}
          {posts.map((post) => {
            const color = colorById(post.color);
            return (
              <div key={post.id} style={{ background: 'white', borderRadius: 16, padding: 14, border: '1.5px solid var(--border)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }}>
                  <div>
                    <span style={{ background: color.bg, color: color.text, border: `1px solid ${color.border}`, borderRadius: 8, padding: '2px 8px', fontSize: 12, fontWeight: 800 }}>{post.code}</span>
                    <div style={{ marginTop: 6, fontWeight: 700 }}>{post.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{post.startTime}–{post.endTime} · {post.habilitatedCount} agent{post.habilitatedCount > 1 ? 's' : ''} habilité{post.habilitatedCount > 1 ? 's' : ''}</div>
                  </div>
                  <button onClick={() => toggleActive(post)} style={{ border: 'none', borderRadius: 20, padding: '6px 10px', cursor: 'pointer', background: post.active ? '#E6F5E7' : '#FDEAEA', color: post.active ? '#3A7D44' : '#A03030', fontWeight: 700, fontSize: 12 }}>
                    {post.active ? 'Actif' : 'Inactif'}
                  </button>
                </div>
                <button onClick={() => openEdit(post)} style={{ marginTop: 10, background: '#171918', color: 'white', border: 'none', borderRadius: 10, padding: '8px 12px', fontWeight: 600, cursor: 'pointer' }}>Modifier</button>
              </div>
            );
          })}
        </div>
      ) : (
        <form onSubmit={save} style={{ padding: '0 16px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <Field label="Nom du poste" value={draft.name} onChange={(name) => setDraft({ ...draft, name })} placeholder="JO" />
          <Field label="Code / abréviation" value={draft.code} onChange={(code) => setDraft({ ...draft, code })} placeholder="JO" />
          <Field label="Description" value={draft.description} onChange={(description) => setDraft({ ...draft, description })} placeholder="Optionnel" />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <Field label="Heure de début" value={draft.startTime} onChange={(startTime) => setDraft({ ...draft, startTime })} type="time" />
            <Field label="Heure de fin" value={draft.endTime} onChange={(endTime) => setDraft({ ...draft, endTime })} type="time" />
          </div>
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6 }}>Couleur du poste</div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {POST_COLORS.map((color) => (
                <button key={color.id} type="button" onClick={() => setDraft({ ...draft, color: color.id })} title={color.label} style={{
                  width: 32, height: 32, borderRadius: 10, background: color.bg, border: draft.color === color.id ? '2px solid #171918' : `1px solid ${color.border}`, cursor: 'pointer',
                }} />
              ))}
            </div>
          </div>
          <button type="button" onClick={() => setDraft({ ...draft, active: !draft.active })} style={{
            alignSelf: 'flex-start', border: 'none', borderRadius: 20, padding: '8px 12px', cursor: 'pointer', fontWeight: 700,
            background: draft.active ? '#E6F5E7' : '#FDEAEA', color: draft.active ? '#3A7D44' : '#A03030',
          }}>{draft.active ? 'Actif' : 'Inactif'}</button>
          <p style={{ margin: 0, fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.4 }}>
            Un poste créé n’habilite personne. Le cadre doit attribuer chaque habilitation.
          </p>
          <button type="submit" disabled={busy} style={{ padding: 14, borderRadius: 14, border: 'none', background: '#171918', color: '#B8E986', fontWeight: 700, cursor: 'pointer' }}>
            {busy ? 'Enregistrement…' : currentId ? 'Enregistrer' : 'Créer le poste'}
          </button>
          {currentId && detail && (
            <div>
              <h2 style={{ fontSize: 16, margin: '8px 0' }}>Habilitations</h2>
              <p style={{ margin: '0 0 8px', fontSize: 12, color: 'var(--text-secondary)' }}>{detail.habilitatedCount} agent{detail.habilitatedCount > 1 ? 's' : ''} habilité{detail.habilitatedCount > 1 ? 's' : ''}</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {detail.agents.map((agent) => (
                  <div key={agent.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'white', borderRadius: 12, padding: '10px 12px' }}>
                    <span style={{ fontSize: 14 }}>{agent.name}</span>
                    <button type="button" onClick={() => toggleAgent(agent.id, !agent.enabled)} style={{
                      border: 'none', borderRadius: 20, padding: '6px 10px', cursor: 'pointer', fontWeight: 700, fontSize: 12,
                      background: agent.enabled ? '#E6F5E7' : '#ECECEC', color: agent.enabled ? '#3A7D44' : '#555',
                    }}>{agent.enabled ? 'Habilité' : 'Non habilité'}</button>
                  </div>
                ))}
              </div>
            </div>
          )}
          {currentId && !confirmDelete && (
            <button type="button" onClick={() => setConfirmDelete(true)} style={{ background: 'none', border: 'none', color: '#A03030', fontWeight: 700, cursor: 'pointer' }}>Supprimer le poste</button>
          )}
          {confirmDelete && (
            <div style={{ background: '#FDEAEA', borderRadius: 12, padding: 12 }}>
              <p style={{ margin: '0 0 8px', fontSize: 13 }}>Supprimer ce poste retire aussi ses habilitations. Les jours déjà planifiés passent en repos.</p>
              <button type="button" onClick={remove} style={{ border: 'none', borderRadius: 10, padding: '8px 12px', background: '#A03030', color: 'white', fontWeight: 700, cursor: 'pointer' }}>Confirmer la suppression</button>
            </div>
          )}
        </form>
      )}
    </div>
  );
}

function Field({ label, value, onChange, placeholder, type = 'text' }: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>{label}</span>
      <input value={value} type={type} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} style={{
        border: '1.5px solid var(--border)', background: 'white', borderRadius: 14, padding: '12px 14px', fontSize: 15, outline: 'none',
      }} />
    </label>
  );
}
