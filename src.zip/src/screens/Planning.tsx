import { useEffect, useState } from 'react';
import { api, type LabPost, type PlanningData } from '../api';
import { colorById } from '../palette';
import Personnel from './Personnel';
import Posts from './Posts';

type ViewMode = 'Jour' | 'Semaine' | 'Mois';

const OFF_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  'R.H.': { bg: '#ECEFF1', text: '#607D8B', border: '#CFD8DC' },
  CA: { bg: '#B2EBF2', text: '#006064', border: '#80DEEA' },
  RTT: { bg: '#B2DFDB', text: '#004D40', border: '#80CBC4' },
  'J.F.': { bg: '#FFF8E1', text: '#F57F17', border: '#FFECB3' },
  ABS: { bg: '#FFCDD2', text: '#B71C1C', border: '#EF9A9A' },
};
const OFF_LEGEND = ['R.H.', 'CA', 'RTT', 'J.F.', 'ABS'];
const DAY_LABELS = ['D', 'L', 'M', 'M', 'J', 'V', 'S'];
const MONTHS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const DAYS = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
const OFF = new Set(['R.H.', 'CA', 'RTT', 'J.F.', 'ABS']);
const FALLBACK = { bg: '#F5F5F5', text: '#666', border: '#E0E0E0' };

function cellStyle(code: string, posts: LabPost[]) {
  const match = posts.find((post) => post.code === code);
  if (match) return colorById(match.color);
  return OFF_COLORS[code] ?? FALLBACK;
}

function iso(date: Date) {
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${date.getFullYear()}-${month}-${day}`;
}

function easterDate(year: number) {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31) - 1;
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month, day);
}

function holidaySet(year: number) {
  const easter = easterDate(year);
  const add = (date: Date, days: number) => {
    const next = new Date(date);
    next.setDate(next.getDate() + days);
    return next;
  };
  const key = (date: Date) => `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
  return new Set([
    key(new Date(year, 0, 1)), key(add(easter, 1)), key(new Date(year, 4, 1)), key(new Date(year, 4, 8)),
    key(add(easter, 39)), key(add(easter, 50)), key(new Date(year, 6, 14)), key(new Date(year, 7, 15)),
    key(new Date(year, 10, 1)), key(new Date(year, 10, 11)), key(new Date(year, 11, 25)),
  ]);
}

function isHoliday(date: Date, set: Set<string>) {
  return set.has(`${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`);
}

function weekDays(date: Date) {
  const start = new Date(date);
  start.setDate(date.getDate() - ((date.getDay() + 6) % 7));
  return Array.from({ length: 7 }, (_, index) => {
    const next = new Date(start);
    next.setDate(start.getDate() + index);
    return next;
  });
}

function monthDays(date: Date) {
  const count = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  return Array.from({ length: count }, (_, index) => new Date(date.getFullYear(), date.getMonth(), index + 1));
}

function PlanCell({ code, hours, compact, posts }: { code: string; hours?: { start: string; end: string }; compact?: boolean; posts: LabPost[] }) {
  const color = cellStyle(code, posts);
  const off = OFF.has(code);
  return (
    <div style={{
      background: color.bg, border: `1px solid ${color.border}`, borderRadius: compact ? 6 : 8,
      padding: compact ? '3px 4px' : '5px 6px', minHeight: compact ? 44 : 60,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    }}>
      {!off && !compact && hours?.start && <span style={{ fontSize: 9, color: color.text, fontWeight: 600 }}>{hours.start}</span>}
      <span style={{ fontSize: compact ? 8 : off ? 11 : 10, fontWeight: 800, color: color.text }}>{code}</span>
      {!off && !compact && hours?.end && <span style={{ fontSize: 9, color: color.text, fontWeight: 600 }}>{hours.end}</span>}
    </div>
  );
}

export default function Planning({ isCadre = false }: { isCadre?: boolean }) {
  const [view, setView] = useState<ViewMode>('Semaine');
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [data, setData] = useState<PlanningData | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [revision, setRevision] = useState(0);
  const [panel, setPanel] = useState<'create' | 'list' | 'personnel' | null>(null);
  const [editing, setEditing] = useState<LabPost | null>(null);

  const days = view === 'Jour' ? [currentDate] : view === 'Semaine' ? weekDays(currentDate) : monthDays(currentDate);
  const from = iso(days[0]);
  const to = iso(days[days.length - 1]);
  const holidays = holidaySet(currentDate.getFullYear());

  useEffect(() => {
    api.planning(from, to)
      .then((result) => { setData(result); setError(''); })
      .catch((err) => setError(err instanceof Error ? err.message : 'Chargement impossible'));
  }, [from, to, revision]);

  function navigate(direction: -1 | 1) {
    const next = new Date(currentDate);
    if (view === 'Jour') next.setDate(next.getDate() + direction);
    else if (view === 'Semaine') next.setDate(next.getDate() + direction * 7);
    else next.setMonth(next.getMonth() + direction);
    setCurrentDate(next);
  }

  function headerLabel() {
    if (view === 'Jour') return `${DAYS[currentDate.getDay()]} ${currentDate.getDate()} ${MONTHS[currentDate.getMonth()]}`;
    if (view === 'Semaine') {
      const span = weekDays(currentDate);
      const start = span[0];
      const end = span[6];
      return start.getMonth() === end.getMonth()
        ? `${start.getDate()}–${end.getDate()} ${MONTHS[start.getMonth()]} ${start.getFullYear()}`
        : `${start.getDate()} ${MONTHS[start.getMonth()].slice(0, 3)} – ${end.getDate()} ${MONTHS[end.getMonth()].slice(0, 3)}`;
    }
    return `${MONTHS[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
  }

  async function generate() {
    setBusy(true);
    try {
      setData(await api.generatePlanning(from, to));
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Génération impossible');
    } finally {
      setBusy(false);
    }
  }

  const lookup = new Map((data?.cells ?? []).map((cell) => [`${cell.userId}|${cell.date}`, cell.code]));
  const agents = data?.agents ?? [];
  const schedule = agents.map((agent) => days.map((day) => lookup.get(`${agent.id}|${iso(day)}`) ?? '—'));
  const compact = view === 'Mois';
  const cellWidth = compact ? 36 : 52;
  const agentWidth = compact ? 72 : 90;
  const today = new Date();

  const posts = data?.posts ?? [];
  const cadre = isCadre || Boolean(data?.canGenerate);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--bg)', position: 'relative' }}>
      <div style={{ flexShrink: 0, paddingTop: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', padding: '0 12px 8px' }}>
          <button onClick={() => navigate(-1)} style={navButton}>‹</button>
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>{headerLabel()}</div>
            <div style={{ fontSize: 10, color: 'var(--text-secondary)', marginTop: 1 }}>
              Planning collectif — {agents.length} agents
            </div>
          </div>
          <button onClick={() => navigate(1)} style={navButton}>›</button>
        </div>
        <div style={{ padding: '0 12px 8px' }}>
          <div style={{ display: 'flex', background: 'white', borderRadius: 12, padding: 3, border: '1.5px solid var(--border)' }}>
            {(['Jour', 'Semaine', 'Mois'] as ViewMode[]).map((item) => (
              <button key={item} onClick={() => setView(item)} style={{
                flex: 1, padding: '7px 0', borderRadius: 9, border: 'none', cursor: 'pointer',
                background: view === item ? '#171918' : 'transparent',
                color: view === item ? '#B8E986' : 'var(--text-secondary)',
                fontSize: 12, fontWeight: 700,
              }}>{item}</button>
            ))}
          </div>
        </div>
        <div style={{ padding: '0 12px 8px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <span style={{ fontSize: 13, fontWeight: 700 }}>Postes disponibles</span>
          <div style={{ display: 'flex', gap: 8, overflowX: 'auto', alignItems: 'center' }} className="scrollbar-hide">
            {posts.map((post) => {
              const color = colorById(post.color);
              return (
                <button key={post.id} onClick={() => { if (!cadre) return; setEditing(post); setPanel('create'); }} style={{
                  flexShrink: 0, borderRadius: 12, padding: '8px 10px', background: color.bg, border: `1px solid ${color.border}`,
                  fontSize: 12, fontWeight: 700, color: color.text, cursor: cadre ? 'pointer' : 'default',
                }}>{cadre ? `Modifier ${post.code}` : post.code}</button>
              );
            })}
            {posts.length === 0 && <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Aucun poste configuré</span>}
          </div>
          {cadre && (
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => { setEditing(null); setPanel('list'); }} style={manageButton}>Gérer les postes</button>
              <button onClick={() => { setEditing(null); setPanel('personnel'); }} style={manageButton}>Gérer les personnel</button>
            </div>
          )}
        </div>
        <div style={{ display: 'flex', gap: 5, padding: '0 12px 8px', overflowX: 'auto' }} className="scrollbar-hide">
          {OFF_LEGEND.map((code) => {
            const color = cellStyle(code, posts);
            return <div key={code} style={{ flexShrink: 0, borderRadius: 20, padding: '3px 8px', background: color.bg, border: `1px solid ${color.border}`, fontSize: 9, fontWeight: 700, color: color.text }}>{code}</div>;
          })}
        </div>
        {error && <p style={{ margin: '0 12px 8px', color: '#A03030', fontSize: 12 }}>{error}</p>}
      </div>

      {view === 'Jour' ? (
        <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 110px' }} className="scrollbar-hide">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {agents.map((agent, index) => {
              const code = schedule[index]?.[0] ?? '—';
              const color = cellStyle(code, posts);
              const hours = data?.hours[code];
              return (
                <div key={agent.id} style={{ background: color.bg, border: `1.5px solid ${color.border}`, borderRadius: 14, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 40, height: 40, borderRadius: '50%', background: color.border, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 800, color: color.text }}>
                    {agent.name.split(' ').map((part) => part[0]).join('')}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: color.text }}>{agent.name}</div>
                    <div style={{ fontSize: 11, color: color.text, opacity: 0.75 }}>{agent.role}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 13, fontWeight: 800, color: color.text }}>{code}</div>
                    {!OFF.has(code) && hours?.start && <div style={{ fontSize: 10, color: color.text, marginTop: 3 }}>{hours.start} → {hours.end}</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div style={{ flex: 1, minHeight: 0, overflow: 'auto', paddingBottom: 88 }} className="scrollbar-hide">
          <div style={{ display: 'flex', minWidth: agentWidth + days.length * cellWidth }}>
            <div style={{ width: agentWidth, flexShrink: 0, position: 'sticky', left: 0, zIndex: 3, background: '#F7F6F1' }}>
              <div style={{ height: compact ? 40 : 50, borderBottom: '1px solid var(--border)', borderRight: '1px solid var(--border)' }} />
              {agents.map((agent, index) => (
                <div key={agent.id} style={{ height: compact ? 52 : 68, padding: '4px 6px', background: index % 2 ? '#FAFAF8' : '#FFFFFF', borderBottom: '1px solid var(--border)', borderRight: '1px solid #D0D0CC', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                  <div style={{ fontSize: compact ? 9 : 10, fontWeight: 700, lineHeight: 1.2 }}>{agent.name.split(' ').slice(1).join(' ') || agent.name}</div>
                  <div style={{ fontSize: compact ? 8 : 9, color: 'var(--text-secondary)' }}>{agent.name.split(' ')[0]}</div>
                </div>
              ))}
              <div style={{ height: 32, padding: '4px 6px', background: '#171918', color: '#B8E986', fontSize: 9, fontWeight: 700, display: 'flex', alignItems: 'center' }}>Nb ag.</div>
            </div>
            <div>
              <div style={{ display: 'flex', height: compact ? 40 : 50, position: 'sticky', top: 0, zIndex: 2, background: '#F7F6F1' }}>
                {days.map((day) => {
                  const current = day.toDateString() === today.toDateString();
                  const holiday = isHoliday(day, holidays);
                  const weekend = day.getDay() === 0 || day.getDay() === 6;
                  return (
                    <div key={iso(day)} style={{ width: cellWidth, flexShrink: 0, borderBottom: '1px solid var(--border)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: current ? '#171918' : holiday ? '#FFF8E1' : weekend ? '#F0F0EC' : '#F7F6F1' }}>
                      <span style={{ fontSize: 9, fontWeight: 700, color: current ? '#B8E986' : 'var(--text-secondary)' }}>{DAY_LABELS[day.getDay()]}</span>
                      <span style={{ fontSize: compact ? 11 : 13, fontWeight: 800, color: current ? 'white' : 'var(--text-primary)' }}>{day.getDate()}</span>
                    </div>
                  );
                })}
              </div>
              {agents.map((agent, agentIndex) => (
                <div key={agent.id} style={{ display: 'flex', height: compact ? 52 : 68, background: agentIndex % 2 ? '#FAFAF8' : '#FFFFFF' }}>
                  {days.map((day, dayIndex) => (
                    <div key={iso(day)} style={{ width: cellWidth, flexShrink: 0, padding: 2, borderBottom: '1px solid var(--border)', borderRight: '1px solid var(--border)' }}>
                      <PlanCell code={schedule[agentIndex][dayIndex]} hours={data?.hours[schedule[agentIndex][dayIndex]]} compact={compact} posts={posts} />
                    </div>
                  ))}
                </div>
              ))}
              <div style={{ display: 'flex', height: 32, background: '#171918' }}>
                {days.map((day, dayIndex) => {
                  const count = schedule.filter((row) => row[dayIndex] && !OFF.has(row[dayIndex]) && row[dayIndex] !== '—').length;
                  return <div key={iso(day)} style={{ width: cellWidth, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: count >= 6 ? '#B8E986' : '#E8AA72', fontSize: 12, fontWeight: 800 }}>{count}</div>;
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {cadre && !panel && (
        <button onClick={generate} disabled={busy} style={{
          position: 'fixed', bottom: 'calc(96px + env(safe-area-inset-bottom))', right: 'max(16px, calc(50% - 199px))',
          background: '#B8E986', color: '#171918', border: 'none', borderRadius: 16, padding: '11px 16px',
          fontSize: 12, fontWeight: 700, cursor: 'pointer', zIndex: 90,
        }}>{busy ? 'Génération…' : 'Générer le planning'}</button>
      )}
      {panel === 'personnel' && (
        <Personnel onClose={() => setPanel(null)} onChanged={() => setRevision((value) => value + 1)} />
      )}
      {(panel === 'create' || panel === 'list') && (
        <Posts
          initial={panel}
          editing={editing}
          onClose={() => setPanel(null)}
          onChanged={() => setRevision((value) => value + 1)}
        />
      )}
    </div>
  );
}

const navButton = {
  background: 'none', border: 'none', cursor: 'pointer', padding: 8, fontSize: 22, color: '#737873',
} as const;

const manageButton = {
  background: 'white', border: '1.5px solid var(--border)', borderRadius: 12,
  padding: '8px 12px', fontSize: 13, fontWeight: 700, color: '#171918', cursor: 'pointer',
} as const;
