import { useEffect, useState } from 'react';
import { api, type RequestsData } from '../api';
import Avatar from '../components/Avatar';
import StatusPill from '../components/StatusPill';
import ExchangePlanning from './ExchangePlanning';

type Category = 'Tout' | 'CA' | 'RTT' | 'Absence' | 'Retard' | 'H. sup.' | 'Échange';
const categories: Category[] = ['Tout', 'CA', 'RTT', 'Absence', 'Retard', 'H. sup.', 'Échange'];

function statusVariant(status: string): 'warning' | 'success' | 'danger' | 'neutral' {
  if (status === 'En attente' || status === 'En attente du collègue') return 'warning';
  if (status === 'Validée') return 'success';
  if (status === 'Refusée') return 'danger';
  return 'neutral';
}

export default function Requests({ viewerId }: { viewerId: number }) {
  const [category, setCategory] = useState<Category>('Tout');
  const [data, setData] = useState<RequestsData | null>(null);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState<number | null>(null);
  const [editing, setEditing] = useState<RequestsData['items'][number] | null>(null);

  async function load(next = category) {
    try {
      setData(await api.requests(next));
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Chargement impossible');
    }
  }

  useEffect(() => { load(category); }, [category]);

  async function reply(id: number, action: 'accept' | 'refuse') {
    setBusyId(id);
    try {
      await api.replyExchange(id, action);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Réponse impossible');
    } finally {
      setBusyId(null);
    }
  }

  async function remove(id: number) {
    if (!window.confirm('Supprimer cette demande d’échange ?')) return;
    setBusyId(id);
    try {
      await api.deleteExchange(id);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Suppression impossible');
    } finally {
      setBusyId(null);
    }
  }

  async function decide(id: number, action: 'approve' | 'reject') {
    setBusyId(id);
    try {
      await api.decide(id, action);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action impossible');
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div style={{ paddingBottom: 100 }}>
      <div style={{ padding: '28px 20px 12px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <h1 style={{ margin: 0, fontSize: 24, fontWeight: 700 }}>Demandes</h1>
        {!!data?.pending && <span style={{ background: '#FEF2F4', color: '#A03030', fontWeight: 700, fontSize: 12, padding: '2px 8px', borderRadius: 20 }}>{data.pending}</span>}
      </div>
      <div style={{ padding: '0 20px 16px', display: 'flex', gap: 8, overflowX: 'auto' }} className="scrollbar-hide">
        {categories.map((item) => (
          <button key={item} onClick={() => setCategory(item)} style={{
            padding: '7px 14px', borderRadius: 20, border: 'none', cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0,
            background: category === item ? '#171918' : 'white', color: category === item ? 'white' : 'var(--text-secondary)',
            fontSize: 12, fontWeight: 600,
          }}>{item}</button>
        ))}
      </div>
      {error && <p style={{ margin: '0 20px 10px', color: '#A03030', fontSize: 13 }}>{error}</p>}
      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {data?.items.map((item) => (
          <div key={item.id} style={{ background: 'white', borderRadius: 16, padding: '14px 16px', boxShadow: '0 2px 10px rgba(0,0,0,0.06)' }}>
            {item.exchange && (
              <div style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>Demande d'échange</div>
                <div style={{ fontSize: 14, fontWeight: 700, marginTop: 6 }}>{item.exchange.fromName} → {item.exchange.toName}</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 4 }}>{item.exchange.dateLabel}</div>
                <div style={{ fontSize: 13, marginTop: 4 }}>{item.exchange.focusLabel}</div>
                {(item.exchange.days?.length > 1 ? item.exchange.days : [{ dateLabel: '', fromCode: item.exchange.fromCode, toCode: item.exchange.toCode }]).map((day) => (
                  <div key={`${day.dateLabel}-${day.fromCode}-${day.toCode}`} style={{ fontSize: 13, marginTop: 4 }}>
                    {day.dateLabel ? `${day.dateLabel} · ` : ''}{item.exchange?.fromName} : {day.fromCode} → {item.exchange?.toName} : {day.toCode}
                  </div>
                ))}
                <div style={{ fontSize: 12, marginTop: 6 }}>Motif : {item.reason}</div>
                {item.exchange.colleagueAccepted && <div style={{ fontSize: 12, color: '#3A7D44', fontWeight: 700, marginTop: 6 }}>{item.exchange.toName} accepte</div>}
                {item.exchange.waitingColleague && <div style={{ fontSize: 12, color: '#A06020', fontWeight: 700, marginTop: 6 }}>En attente de {item.exchange.toName}</div>}
                {item.canApproveExchange && <div style={{ fontSize: 12, color: '#A06020', fontWeight: 700, marginTop: 4 }}>En attente de validation cadre</div>}
              </div>
            )}
            {!item.exchange && <div style={{ display: 'flex', gap: 10 }}>
              <Avatar name={item.name} size={40} />
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{item.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 1 }}>{item.dates}</div>
                  </div>
                  <span style={{ background: '#171918', color: 'white', fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 7, height: 'fit-content' }}>{item.type}</span>
                </div>
                <div style={{ fontSize: 12, marginTop: 6 }}>{item.reason}</div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
                  <StatusPill label={item.status} variant={statusVariant(item.status)} />
                  <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{item.createdLabel}</span>
                </div>
              </div>
            </div>}
            {item.exchange && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <StatusPill label={item.status} variant={statusVariant(item.status)} />
                <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{item.createdLabel}</span>
              </div>
            )}
            {item.canManageExchange && item.exchange && (
              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <button disabled={busyId === item.id} onClick={() => remove(item.id)} style={{ flex: 1, padding: 9, borderRadius: 12, border: '1.5px solid #D98282', background: 'white', color: '#D98282', fontWeight: 600, cursor: 'pointer' }}>Supprimer</button>
                <button disabled={busyId === item.id} onClick={() => setEditing(item)} style={{ flex: 1, padding: 9, borderRadius: 12, border: 'none', background: '#171918', color: '#B8E986', fontWeight: 700, cursor: 'pointer' }}>Modifier</button>
              </div>
            )}
            {item.canAnswerExchange && (
              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <button disabled={busyId === item.id} onClick={() => reply(item.id, 'refuse')} style={{ flex: 1, padding: 9, borderRadius: 12, border: '1.5px solid #D98282', background: 'white', color: '#D98282', fontWeight: 600, cursor: 'pointer' }}>Refuser</button>
                <button disabled={busyId === item.id} onClick={() => reply(item.id, 'accept')} style={{ flex: 1, padding: 9, borderRadius: 12, border: 'none', background: '#171918', color: '#B8E986', fontWeight: 700, cursor: 'pointer' }}>Accepter</button>
              </div>
            )}
            {(item.canValidate || item.canApproveExchange) && (
              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <button disabled={busyId === item.id} onClick={() => decide(item.id, 'reject')} style={{ flex: 1, padding: 9, borderRadius: 12, border: '1.5px solid #D98282', background: 'white', color: '#D98282', fontWeight: 600, cursor: 'pointer' }}>Refuser</button>
                <button disabled={busyId === item.id} onClick={() => decide(item.id, 'approve')} style={{ flex: 1, padding: 9, borderRadius: 12, border: 'none', background: '#B8E986', color: '#171918', fontWeight: 700, cursor: 'pointer' }}>{item.canApproveExchange ? 'Approuver' : 'Valider'}</button>
              </div>
            )}
          </div>
        ))}
        {data && data.items.length === 0 && <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>Aucune demande.</p>}
      </div>
      {editing?.exchange && (
        <ExchangePlanning
          partnerId={editing.exchange.partnerId}
          partnerName={editing.exchange.toName}
          viewerId={viewerId}
          requestId={editing.id}
          initialStart={editing.exchange.startDate}
          initialEnd={editing.exchange.endDate}
          initialReason={editing.reason}
          onClose={() => { setEditing(null); load(); }}
        />
      )}
    </div>
  );
}

